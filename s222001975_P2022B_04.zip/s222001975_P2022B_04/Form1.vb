﻿'Surname and initials: Mayet,AA
'Student number: 222001975
'Practical: 04

Option Explicit On
Option Infer Off
Option Strict On

Public Class frmSUPI

    Private Puppies() As Puppy
    Private Cost As Integer
    Private nPup As Integer
    Private nDay As Integer
    Private TotalFood As Double
    Private TotalCost As Double

    Private Sub SetGrid(ByVal C As Integer, ByVal R As Integer)
        grdSUPI.Rows = R
        grdSUPI.Cols = C
    End Sub

    Private Sub DispGrid(ByVal c As Integer, ByVal r As Integer, ByVal t As String)
        grdSUPI.Col = c
        grdSUPI.Row = r
        grdSUPI.Text = t
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        SetGrid(10, 10)
        DispGrid(0, 0, "Name")
        DispGrid(1, 0, "Breed")
        DispGrid(2, 0, "Gender")
        DispGrid(3, 0, "Age")
        DispGrid(4, 0, "Weight per Day")
        DispGrid(5, 0, "Total Food Fed")
        nPup = 0
        nDay = 0
        TotalCost = 0
        TotalFood = 0

    End Sub

    Private Sub btnInitial_Click(sender As Object, e As EventArgs) Handles btnInitial.Click

        'Get no. puppies, dyas, and cost per kg of food
        nPup = CInt(InputBox("How many Puppies are there?"))
        nDay = CInt(InputBox("How many days are you keeping the puppies for?"))
        Cost = CInt(InputBox("How much does 1Kg of food cost?"))

        'Construct objects
        ReDim Puppies(nPup)
        Dim p As Integer
        For p = 1 To nPup
            Puppies(p) = New Puppy(nDay)
        Next

        'set up grid disp
        SetGrid(nDay + 4, nPup + 1)
        DispGrid(0, 0, "Name")
        DispGrid(1, 0, "Breed")
        DispGrid(2, 0, "Age(months)")
        Dim d As Integer
        For d = 1 To nDay
            DispGrid(2 + d, 0, "Weight (g) Day " & d)
        Next d
        DispGrid(nDay + 3, 0, "Total food (g)")

    End Sub

    Private Sub bntInput_Click(sender As Object, e As EventArgs) Handles bntInput.Click

        Dim p As Integer
        For p = 1 To nPup

            'Get name, breed, gender, and age per puppy
            Puppies(p).Name = InputBox("What is the name of puppy " & p)
            DispGrid(0, p, Puppies(p).Name)
            Puppies(p).Breed = InputBox("What breed is " & Puppies(p).Name)
            DispGrid(1, p, Puppies(p).Breed)
            Puppies(p).Gender = InputBox("What gender is " & Puppies(p).Name & " M or F")
            Puppies(p).Age = CInt(InputBox("How old is " & Puppies(p).Name))
            DispGrid(2, p, CStr(Puppies(p).Age))

        Next

    End Sub

    Private Sub btnWeight_Click(sender As Object, e As EventArgs) Handles btnWeight.Click

        Dim p As Integer
        Dim d As Integer
        For p = 1 To nPup
            For d = 1 To nDay

                'get weight per day per puppy
                Puppies(p).Weight(d) = CInt(InputBox("How much did " & Puppies(p).Name & " weigh (g) on day " & d))
                DispGrid(2 + d, p, CStr(Puppies(p).Weight(d)))

            Next d
        Next p

    End Sub

    Private Sub btnFoodperPup_Click(sender As Object, e As EventArgs) Handles btnFoodperPup.Click

        Dim food As Integer
        Dim TFoodPup As Integer
        Dim p As Integer
        Dim d As Integer

        For p = 1 To nPup

            TFoodPup = 0

            For d = 1 To nDay

                'calc total food fed per puppy
                food = Puppies(p).FoodFed(d)
                TFoodPup += food

            Next d

            DispGrid(nDay + 3, p, CStr(TFoodPup))

        Next p

    End Sub

    Private Sub btnTFoodCost_Click(sender As Object, e As EventArgs) Handles btnTFoodCost.Click

        Dim TFoodPup As Integer
        Dim p As Integer
        Dim d As Integer

        TotalFood = 0

        For p = 1 To nPup

            TFoodPup = 0

            For d = 1 To nDay

                TFoodPup += Puppies(p).FoodFed(d)

            Next d

            'Calc total food fed
            TotalFood += TFoodPup

        Next p

        'calc cost
        TotalFood /= 1000
        TotalCost = TotalFood * Cost
        txtOverCost.Text = "R " & CStr(TotalCost)
        txtOverFood.Text = CStr(TotalFood) & " Kg"

    End Sub

End Class
