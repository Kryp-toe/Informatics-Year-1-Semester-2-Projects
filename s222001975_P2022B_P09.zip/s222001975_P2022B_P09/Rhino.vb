﻿' *********************************************************************************
' Surname, Initials: Mayet, AA
' Student Number: 222001975
' Practical: P2022-09
' Class/Interface name: Rhino
' *********************************************************************************

Option Infer Off
Option Strict On
Option Explicit On

<Serializable()> Public Class Rhino

    Inherits Wildlife
    Private _Crash As Integer

    'Constructor
    Public Sub New(id As String, level As Integer, numcrash As Integer)
        MyBase.New(id, level, 2)
        _Crash = numcrash
    End Sub

    'Methods
    Public Overrides Function CalcRarityRating() As String
        Return "A"
    End Function

    Public Overrides Function Display() As String
        Return MyBase.Display() & " / " & CalcRarityRating() & " / " & _Crash
    End Function

End Class
