﻿'*********************************************************************************************
' Surname, Initials: Mayet, AA
' Student Number: 222001975
' Practical: P06
'*********************************************************************************************

Option Explicit On
Option Strict On
Option Infer Off

Public Class frmSportTracker

    'Declare base class
    Private objSport() As Sport

    'sub for grid
    Private Sub SetGrid(ByVal C As Integer, ByVal R As Integer)
        grdSportTracker.Rows = R
        grdSportTracker.Cols = C
    End Sub

    Private Sub DispGrid(ByVal c As Integer, ByVal r As Integer, t As String)
        grdSportTracker.Row = r
        grdSportTracker.Col = c
        grdSportTracker.Text = t
    End Sub

    'Sub used for displaying the team scores
    Private Sub DispScores(ByVal x As Integer)

        SetGrid(5, objSport(x).nteams + 1)
        DispGrid(0, 0, "Team Name")
        DispGrid(1, 0, "Team Score")
        DispGrid(2, 0, "-")
        grdSportTracker.set_ColWidth(2, 20)
        DispGrid(3, 0, "Opponenet score")
        DispGrid(4, 0, "Opponent Team")

        Dim t As Integer
        For t = 1 To objSport(x).nteams

            DispGrid(0, t, objSport(x).Teams(t).Name)
            DispGrid(1, t, objSport(x).Teams(t).TeamScore)
            DispGrid(2, t, "-")
            DispGrid(3, t, objSport(x).Teams(t).OppoScore)
            DispGrid(4, t, objSport(x).Teams(t).Opponent)

        Next t

    End Sub

    'Sub used for capturing the Sport information
    Private Sub Capt(ByVal y As Integer, ByVal z As String)

        'Set up grid
        Dim t As Integer
        SetGrid(3, objSport(y).nteams + 1)
        DispGrid(0, 0, "Team Name")
        DispGrid(1, 0, "Number of players")
        DispGrid(2, 0, "Opponent")

        For t = 1 To objSport(y).nteams

            Dim name As String
            Dim players As Integer
            Dim oppo As String

            'Get team information for each sport

            name = InputBox("What is the name of Team " & t & " in " & z)
            DispGrid(0, t, name)
            players = CInt(InputBox("WHow many players are in Team " & name & " in " & z))
            DispGrid(1, t, CStr(players))
            oppo = InputBox("What is the name of the Opposing Team for " & name & " in " & z)
            DispGrid(2, t, oppo)

            'create team objects
            objSport(y).Teams(t) = New Team(name, players, oppo)

        Next t

    End Sub

    Private Sub frmSportTracker_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        SetGrid(8, 5)
        DispGrid(0, 0, "Team Name")
        DispGrid(1, 0, "Team Score")
        DispGrid(2, 0, "Opponenet score")
        DispGrid(3, 0, "Opponent Team")

        ReDim objSport(3)

    End Sub

    Private Sub btnInitial_Click(sender As Object, e As EventArgs) Handles btnInitial.Click

        'Create objects for each child class
        Dim nteams As Integer
        nteams = CInt(InputBox("How many teams are in Soccer"))
        objSport(1) = New Soccer(nteams)
        objSport(1).nteams = nteams

        nteams = CInt(InputBox("How many teams are in Cricket"))
        objSport(2) = New Cricket(nteams)
        objSport(2).nteams = nteams

        nteams = CInt(InputBox("How many teams are in Rugby?"))
        objSport(3) = New Rugby(nteams)
        objSport(3).nteams = nteams

    End Sub

    Private Sub btnCaptSport_Click(sender As Object, e As EventArgs) Handles btnCaptSport.Click

        'Run sub for each sport
        Capt(1, "Soccer")
        Capt(2, "Cricket")
        Capt(3, "Rugby")

    End Sub

    Private Sub btnCaptScore_Click(sender As Object, e As EventArgs) Handles btnCaptScore.Click

        'set up grid
        SetGrid(4, 1)
        DispGrid(0, 0, "Team Name")
        DispGrid(1, 0, "Team Score")
        DispGrid(2, 0, "Opponenet score")
        DispGrid(3, 0, "Opponent Team")

        'get which sport the user wants to capture
        Dim capt As String
        capt = InputBox("Which sport score would you like to capture?" & vbNewLine & "1. Soccer" & vbNewLine & "2. Cricket" & vbNewLine & "3. Rugby")

        Select Case capt

            'Soccer
            Case "1"

                Dim t As Integer
                For t = 1 To objSport(1).nteams

                    Dim goals As Integer

                    goals = CInt(InputBox("How many goals did " & objSport(1).Teams(t).Name & " score?"))
                    objSport(1).Teams(t).TeamScore = objSport(1).CalcScore(goals, 0, 0, 0)

                    goals = CInt(InputBox("How many goals did " & objSport(1).Teams(t).Opponent & " score?"))
                    objSport(1).Teams(t).OppoScore = objSport(1).CalcScore(goals, 0, 0, 0)

                    DispScores(1)

                Next

            'Cricket
            Case "2"

                Dim t As Integer
                For t = 1 To objSport(2).nteams

                    Dim runs As Integer
                    Dim wickets As Integer

                    runs = CInt(InputBox("How many runs did " & objSport(2).Teams(t).Name & " make?"))
                    wickets = CInt(InputBox("How many wickets did " & objSport(2).Teams(t).Name & " conceed?"))

                    objSport(2).Teams(t).TeamScore = objSport(2).CalcScore(runs, wickets, 0, 0)

                    runs = CInt(InputBox("How many runs did " & objSport(2).Teams(t).Opponent & " make?"))
                    wickets = CInt(InputBox("How many wickets did " & objSport(2).Teams(t).Opponent & " conceed?"))

                    objSport(2).Teams(t).OppoScore = objSport(2).CalcScore(runs, wickets, 0, 0)

                    DispScores(2)

                Next

            'Rugby
            Case "3"

                Dim t As Integer
                For t = 1 To objSport(3).nteams

                    Dim trie As Integer
                    Dim conversion As Integer
                    Dim penalty As Integer
                    Dim dropgoal As Integer

                    trie = CInt(InputBox("How many tries did " & objSport(3).Teams(t).Name & " score?"))
                    conversion = CInt(InputBox("How many conversions did " & objSport(3).Teams(t).Name & " score?"))
                    penalty = CInt(InputBox("How many penalties did " & objSport(3).Teams(t).Name & " score?"))
                    dropgoal = CInt(InputBox("How many drop goals did " & objSport(3).Teams(t).Name & " score?"))

                    objSport(3).Teams(t).TeamScore = objSport(2).CalcScore(trie, conversion, penalty, dropgoal)

                    trie = CInt(InputBox("How many tries did " & objSport(3).Teams(t).Opponent & " score?"))
                    conversion = CInt(InputBox("How many conversions did " & objSport(3).Teams(t).Opponent & " score?"))
                    penalty = CInt(InputBox("How many penalties did " & objSport(3).Teams(t).Opponent & " score?"))
                    dropgoal = CInt(InputBox("How many drop goals did " & objSport(3).Teams(t).Opponent & " score?"))

                    objSport(3).Teams(t).OppoScore = objSport(2).CalcScore(trie, conversion, penalty, dropgoal)

                    DispScores(3)

                Next


            Case Else

                MsgBox("Please click the button again and select a number indicated above")

        End Select

    End Sub

    Private Sub btnView_Click(sender As Object, e As EventArgs) Handles btnView.Click

        'Ask user which sport they want to view
        Dim view As Integer
        view = CInt(InputBox("What sport score would you like to view?" & vbNewLine & "1. Soccer" & vbNewLine & "2. Cricket" & vbNewLine & "3. Rugby"))

        Select Case view

            'Soccer
            Case 1

                DispScores(1)

            'Cricket
            Case 2

                DispScores(2)

            'Rugby
            Case 3

                DispScores(3)

            Case Else

                MsgBox("Please click the button again and select a number indicated above")

        End Select

    End Sub

End Class
