﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmGolf
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.grdGolf = New UJGrid.UJGrid()
        Me.btnInput = New System.Windows.Forms.Button()
        Me.btnScore = New System.Windows.Forms.Button()
        Me.btnAvg = New System.Windows.Forms.Button()
        Me.btnWoBe = New System.Windows.Forms.Button()
        Me.btnInitial = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'grdGolf
        '
        Me.grdGolf.FixedCols = 1
        Me.grdGolf.FixedRows = 1
        Me.grdGolf.Location = New System.Drawing.Point(12, 56)
        Me.grdGolf.Name = "grdGolf"
        Me.grdGolf.Scrollbars = System.Windows.Forms.ScrollBars.Both
        Me.grdGolf.Size = New System.Drawing.Size(619, 150)
        Me.grdGolf.TabIndex = 0
        '
        'btnInput
        '
        Me.btnInput.Location = New System.Drawing.Point(137, 12)
        Me.btnInput.Name = "btnInput"
        Me.btnInput.Size = New System.Drawing.Size(119, 38)
        Me.btnInput.TabIndex = 1
        Me.btnInput.Text = "Input"
        Me.btnInput.UseVisualStyleBackColor = True
        '
        'btnScore
        '
        Me.btnScore.Location = New System.Drawing.Point(262, 12)
        Me.btnScore.Name = "btnScore"
        Me.btnScore.Size = New System.Drawing.Size(119, 38)
        Me.btnScore.TabIndex = 2
        Me.btnScore.Text = "Score"
        Me.btnScore.UseVisualStyleBackColor = True
        '
        'btnAvg
        '
        Me.btnAvg.Location = New System.Drawing.Point(387, 12)
        Me.btnAvg.Name = "btnAvg"
        Me.btnAvg.Size = New System.Drawing.Size(119, 38)
        Me.btnAvg.TabIndex = 3
        Me.btnAvg.Text = "Average Score"
        Me.btnAvg.UseVisualStyleBackColor = True
        '
        'btnWoBe
        '
        Me.btnWoBe.Location = New System.Drawing.Point(512, 12)
        Me.btnWoBe.Name = "btnWoBe"
        Me.btnWoBe.Size = New System.Drawing.Size(119, 38)
        Me.btnWoBe.TabIndex = 4
        Me.btnWoBe.Text = "Best/Worse Score"
        Me.btnWoBe.UseVisualStyleBackColor = True
        '
        'btnInitial
        '
        Me.btnInitial.Location = New System.Drawing.Point(12, 12)
        Me.btnInitial.Name = "btnInitial"
        Me.btnInitial.Size = New System.Drawing.Size(119, 38)
        Me.btnInitial.TabIndex = 5
        Me.btnInitial.Text = "Intialize"
        Me.btnInitial.UseVisualStyleBackColor = True
        '
        'frmGolf
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(644, 240)
        Me.Controls.Add(Me.btnInitial)
        Me.Controls.Add(Me.btnWoBe)
        Me.Controls.Add(Me.btnAvg)
        Me.Controls.Add(Me.btnScore)
        Me.Controls.Add(Me.btnInput)
        Me.Controls.Add(Me.grdGolf)
        Me.Name = "frmGolf"
        Me.Text = "Golf for Pros"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents grdGolf As UJGrid.UJGrid
    Friend WithEvents btnInput As Button
    Friend WithEvents btnScore As Button
    Friend WithEvents btnAvg As Button
    Friend WithEvents btnWoBe As Button
    Friend WithEvents btnInitial As Button
End Class
