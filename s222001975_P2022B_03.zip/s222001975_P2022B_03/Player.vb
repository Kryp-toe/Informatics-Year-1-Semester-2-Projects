﻿'********************************************************************************************* 
'  Surname, Initials:  Mayet, AA
'  Student Number:  222001975
'  Practical: P03 
'********************************************************************************************* 

Option Explicit On
Option Infer Off
Option Strict On

Public Class Player

    Private _Name As String
    Private _Handicap As Integer
    Private _Score() As Integer

    'Allow the form to access the variables in the class, using property 
    Public Property Name() As String
        Get
            Return _Name
        End Get
        Set(value As String)
            _Name = value
        End Set
    End Property

    Public Property Handicap() As Integer
        Get
            Return _Handicap
        End Get
        Set(value As Integer)
            _Handicap = value
        End Set
    End Property

    'Construct the array for score
    Public Sub New(courses As Integer)
        ReDim _Score(courses)
    End Sub

    'Size the array
    Public Sub SetCourses(courses As Integer)
        ReDim Preserve _Score(courses)
    End Sub

    'Allow acess to array
    Public Property Score(index As Integer) As Integer
        Get
            Return _Score(index)
        End Get
        Set(value As Integer)
            _Score(index) = value
        End Set
    End Property

    'cal avg score function
    Public Function AvgScore(courses As Integer) As Double

        Dim p As Integer
        Dim c As Integer
        Dim total As Integer

        total = 0

        For c = 1 To courses

            total += Score(c)

        Next

        Return total / courses

    End Function

    'find best/worse function
    Public Function BestFunc(courses As Integer) As Integer

        Dim best As Integer
        Dim c As Integer

        best = Score(1)

        For c = 2 To courses

            If best > Score(c) Then
                best = Score(c)
            End If


        Next

        Return best

    End Function

    Public Function WorstFunc(courses As Integer) As Integer

        Dim worst As Integer
        Dim c As Integer

        worst = Score(1)

        For c = 2 To courses

            If worst < Score(c) Then
                worst = Score(c)
            End If

        Next

        Return worst

    End Function

End Class
