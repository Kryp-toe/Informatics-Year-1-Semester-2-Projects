﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmSportTracker
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.grdSportTracker = New UJGrid.UJGrid()
        Me.btnInitial = New System.Windows.Forms.Button()
        Me.btnCaptScore = New System.Windows.Forms.Button()
        Me.btnView = New System.Windows.Forms.Button()
        Me.btnCaptSport = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'grdSportTracker
        '
        Me.grdSportTracker.FixedCols = 1
        Me.grdSportTracker.FixedRows = 1
        Me.grdSportTracker.Location = New System.Drawing.Point(12, 56)
        Me.grdSportTracker.Name = "grdSportTracker"
        Me.grdSportTracker.Scrollbars = System.Windows.Forms.ScrollBars.Both
        Me.grdSportTracker.Size = New System.Drawing.Size(310, 150)
        Me.grdSportTracker.TabIndex = 0
        '
        'btnInitial
        '
        Me.btnInitial.Location = New System.Drawing.Point(12, 12)
        Me.btnInitial.Name = "btnInitial"
        Me.btnInitial.Size = New System.Drawing.Size(73, 38)
        Me.btnInitial.TabIndex = 1
        Me.btnInitial.Text = "Initialize"
        Me.btnInitial.UseVisualStyleBackColor = True
        '
        'btnCaptScore
        '
        Me.btnCaptScore.Location = New System.Drawing.Point(170, 12)
        Me.btnCaptScore.Name = "btnCaptScore"
        Me.btnCaptScore.Size = New System.Drawing.Size(73, 38)
        Me.btnCaptScore.TabIndex = 5
        Me.btnCaptScore.Text = "Capture Scores"
        Me.btnCaptScore.UseVisualStyleBackColor = True
        '
        'btnView
        '
        Me.btnView.Location = New System.Drawing.Point(249, 12)
        Me.btnView.Name = "btnView"
        Me.btnView.Size = New System.Drawing.Size(73, 38)
        Me.btnView.TabIndex = 6
        Me.btnView.Text = "View Scores"
        Me.btnView.UseVisualStyleBackColor = True
        '
        'btnCaptSport
        '
        Me.btnCaptSport.Location = New System.Drawing.Point(91, 12)
        Me.btnCaptSport.Name = "btnCaptSport"
        Me.btnCaptSport.Size = New System.Drawing.Size(73, 38)
        Me.btnCaptSport.TabIndex = 7
        Me.btnCaptSport.Text = "Capture Sport"
        Me.btnCaptSport.UseVisualStyleBackColor = True
        '
        'frmSportTracker
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(336, 234)
        Me.Controls.Add(Me.btnCaptSport)
        Me.Controls.Add(Me.btnView)
        Me.Controls.Add(Me.btnCaptScore)
        Me.Controls.Add(Me.btnInitial)
        Me.Controls.Add(Me.grdSportTracker)
        Me.Name = "frmSportTracker"
        Me.Text = "Sport Tracker"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents grdSportTracker As UJGrid.UJGrid
    Friend WithEvents btnInitial As Button
    Friend WithEvents btnCaptScore As Button
    Friend WithEvents btnView As Button
    Friend WithEvents btnCaptSport As Button
End Class
