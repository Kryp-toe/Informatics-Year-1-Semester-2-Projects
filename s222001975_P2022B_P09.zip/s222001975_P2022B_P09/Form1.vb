﻿' *********************************************************************************
' Surname, Initials: Mayet, AA
' Student Number: 222001975
' Practical: P2022-09
' Class/Interface name: frmWildLifeTracker
' *********************************************************************************

Option Infer Off
Option Strict On
Option Explicit On
Imports System.IO
Imports System.Runtime.Serialization.Formatters.Binary

Public Class frmWildLifeTracker

    Private NumWildLife As Integer
    Private WildLifeAnimal() As Wildlife
    Private File As FileStream
    Private Binary As BinaryFormatter
    Private FileName As String = "Rhino"
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        txtDisplayAll.Text = "Display for all Wildlife"
        txtDisplayRhino.Text = "Display for Rhino file"
    End Sub

    Private Sub btnSetUp_Click(sender As Object, e As EventArgs) Handles btnSetUp.Click

        'get number of wildlife
        NumWildLife = CInt(InputBox("How many Wildlife Animals are you tracking?"))
        ReDim Preserve WildLifeAnimal(NumWildLife)

        'for every wildlife
        Dim choice As Integer
        Dim n As Integer
        For n = 1 To NumWildLife
            choice = CInt(InputBox("What Animal is Number " & n & vbNewLine & " 1. Lion " & vbNewLine & " 2. Rhino "))

            Dim ID As String
            Dim Level, Months As Integer
            Select Case choice

                'Lion
                Case 1

                    Dim objLion As Lion

                    ID = InputBox("What is the Tracking ID of the Lion?")
                    Level = CInt(InputBox("What is the Rarity Level of Lion " & ID))
                    Months = CInt(InputBox("How many months was Lion " & ID & " monitored for?"))

                    'Create object
                    objLion = New Lion(ID, Level, Months)

                    objLion.Pride = CInt(InputBox("How many Lions are in this Pride?"))

                    Dim alphachoice As Integer
                    alphachoice = CInt(InputBox("Is the Lion an Alpha Male or Not?" & vbNewLine & " 1. Yes " & vbNewLine & " 2. No "))
                    If alphachoice = 1 Then
                        objLion.IsAlpha = True
                    End If
                    If alphachoice = 2 Then
                        objLion.IsAlpha = False
                    End If

                    Dim s As Integer
                    For s = 1 To Months

                        objLion.Sightings(s) = CInt(InputBox("How many times was Lion " & ID & " spotted" & " in month " & s))

                    Next

                    'PLace object into array
                    WildLifeAnimal(n) = objLion
                    txtDisplayAll.Text = "ID : Rare Level / Avg Sightings / Least Sighted / Rarity / No. Lions / Alpha " & vbNewLine & objLion.Display()



                'Rhino
                Case 2

                    Dim objRhino As Rhino
                    Dim crash As Integer
                    ID = InputBox("What is the Tracking ID of the Rhino?")
                    Level = CInt(InputBox("What is the Rarity Level of Rhino " & ID))
                    crash = CInt(InputBox("How many Rhinos in the Family for " & ID & " ?"))

                    'Create object
                    objRhino = New Rhino(ID, Level, crash)

                    Dim s As Integer
                    For s = 1 To 2

                        objRhino.Sightings(s) = CInt(InputBox("How many times was Rhino " & ID & " spotted" & " in month " & s))

                    Next

                    'Place object into array
                    WildLifeAnimal(n) = objRhino
                    txtDisplayAll.Text = "ID : Rarity Level / Avg Sighting / Least Sighted / Rarity / Crash " & vbNewLine & objRhino.Display()

            End Select

        Next


    End Sub

    'Display all animal info
    Private Sub btnDisplay_Click(sender As Object, e As EventArgs) Handles btnDisplay.Click

        txtDisplayAll.Text = " "

        Dim n As Integer
        For n = 1 To NumWildLife
            txtDisplayAll.Text &= WildLifeAnimal(n).Display & vbNewLine
        Next

    End Sub

    'Change animal ratings
    Private Sub btnRating_Click(sender As Object, e As EventArgs) Handles btnRating.Click

        txtDisplayAll.Text = " "

        Dim n As Integer
        Dim rating As String
        For n = 1 To NumWildLife
            rating = WildLifeAnimal(n).CalcRarityRating()
            txtDisplayAll.Text = n & " : " & rating
        Next

        MsgBox("Rating has been changed")

    End Sub

    Private Sub btnSaveFile_Click(sender As Object, e As EventArgs) Handles btnSaveFile.Click

        txtDisplayAll.Text = " "

        'Create filestream and binary formatter
        Dim objRhino As Rhino
        File = New FileStream(FileName, FileMode.Create, FileAccess.ReadWrite)
        Binary = New BinaryFormatter()

        'Save items to file
        Dim n As Integer
        For n = 1 To NumWildLife
            objRhino = TryCast(WildLifeAnimal(n), Rhino)

            If Not (objRhino Is Nothing) Then
                Binary.Serialize(File, objRhino)
            End If

        Next n

        File.Close()
        MsgBox("Your File has been Saved")

    End Sub

    Private Sub btnDisplayFile_Click(sender As Object, e As EventArgs) Handles btnDisplayFile.Click

        txtDisplayAll.Text = " "
        txtDisplayRhino.Text = " "

        'Filestream and biary formatter
        Dim objRhino As Rhino
        File = New FileStream(FileName, FileMode.Open, FileAccess.ReadWrite)
        Binary = New BinaryFormatter()

        'open file and display data
        While File.Position < File.Length

            objRhino = DirectCast(Binary.Deserialize(File), Rhino)
            txtDisplayRhino.Text &= vbNewLine & objRhino.Display

        End While

        File.Close()

    End Sub

End Class
