﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmGrillMealScore
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.grdGrillMealScore = New UJGrid.UJGrid()
        Me.btnCaptData = New System.Windows.Forms.Button()
        Me.btnAvgChef = New System.Windows.Forms.Button()
        Me.btnAvgJudge = New System.Windows.Forms.Button()
        Me.btnRate = New System.Windows.Forms.Button()
        Me.btnOverallAvgJ = New System.Windows.Forms.Button()
        Me.btnFlag = New System.Windows.Forms.Button()
        Me.btnHighChef = New System.Windows.Forms.Button()
        Me.txtOverallJ = New System.Windows.Forms.TextBox()
        Me.txtFlag = New System.Windows.Forms.TextBox()
        Me.txtHigh = New System.Windows.Forms.TextBox()
        Me.grdJudges = New UJGrid.UJGrid()
        Me.SuspendLayout()
        '
        'grdGrillMealScore
        '
        Me.grdGrillMealScore.Cols = 5
        Me.grdGrillMealScore.FixedCols = 1
        Me.grdGrillMealScore.FixedRows = 1
        Me.grdGrillMealScore.Location = New System.Drawing.Point(12, 60)
        Me.grdGrillMealScore.Name = "grdGrillMealScore"
        Me.grdGrillMealScore.Scrollbars = System.Windows.Forms.ScrollBars.Both
        Me.grdGrillMealScore.Size = New System.Drawing.Size(503, 200)
        Me.grdGrillMealScore.TabIndex = 0
        '
        'btnCaptData
        '
        Me.btnCaptData.Location = New System.Drawing.Point(12, 12)
        Me.btnCaptData.Name = "btnCaptData"
        Me.btnCaptData.Size = New System.Drawing.Size(109, 42)
        Me.btnCaptData.TabIndex = 1
        Me.btnCaptData.Text = "Capture Data"
        Me.btnCaptData.UseVisualStyleBackColor = True
        '
        'btnAvgChef
        '
        Me.btnAvgChef.Location = New System.Drawing.Point(146, 12)
        Me.btnAvgChef.Name = "btnAvgChef"
        Me.btnAvgChef.Size = New System.Drawing.Size(109, 42)
        Me.btnAvgChef.TabIndex = 2
        Me.btnAvgChef.Text = "Average Score (Chef)"
        Me.btnAvgChef.UseVisualStyleBackColor = True
        '
        'btnAvgJudge
        '
        Me.btnAvgJudge.Location = New System.Drawing.Point(279, 12)
        Me.btnAvgJudge.Name = "btnAvgJudge"
        Me.btnAvgJudge.Size = New System.Drawing.Size(109, 42)
        Me.btnAvgJudge.TabIndex = 3
        Me.btnAvgJudge.Text = "Averge Score (Judges)"
        Me.btnAvgJudge.UseVisualStyleBackColor = True
        '
        'btnRate
        '
        Me.btnRate.Location = New System.Drawing.Point(406, 12)
        Me.btnRate.Name = "btnRate"
        Me.btnRate.Size = New System.Drawing.Size(109, 42)
        Me.btnRate.TabIndex = 4
        Me.btnRate.Text = "Rating"
        Me.btnRate.UseVisualStyleBackColor = True
        '
        'btnOverallAvgJ
        '
        Me.btnOverallAvgJ.Location = New System.Drawing.Point(201, 422)
        Me.btnOverallAvgJ.Name = "btnOverallAvgJ"
        Me.btnOverallAvgJ.Size = New System.Drawing.Size(109, 42)
        Me.btnOverallAvgJ.TabIndex = 5
        Me.btnOverallAvgJ.Text = "Overall Average (by Judges)"
        Me.btnOverallAvgJ.UseVisualStyleBackColor = True
        '
        'btnFlag
        '
        Me.btnFlag.Location = New System.Drawing.Point(201, 470)
        Me.btnFlag.Name = "btnFlag"
        Me.btnFlag.Size = New System.Drawing.Size(109, 42)
        Me.btnFlag.TabIndex = 6
        Me.btnFlag.Text = "Flagged Chefs"
        Me.btnFlag.UseVisualStyleBackColor = True
        '
        'btnHighChef
        '
        Me.btnHighChef.Location = New System.Drawing.Point(201, 518)
        Me.btnHighChef.Name = "btnHighChef"
        Me.btnHighChef.Size = New System.Drawing.Size(109, 42)
        Me.btnHighChef.TabIndex = 7
        Me.btnHighChef.Text = "Highest Average (Chef)"
        Me.btnHighChef.UseVisualStyleBackColor = True
        '
        'txtOverallJ
        '
        Me.txtOverallJ.Location = New System.Drawing.Point(15, 444)
        Me.txtOverallJ.Name = "txtOverallJ"
        Me.txtOverallJ.Size = New System.Drawing.Size(180, 20)
        Me.txtOverallJ.TabIndex = 9
        '
        'txtFlag
        '
        Me.txtFlag.Location = New System.Drawing.Point(15, 492)
        Me.txtFlag.Name = "txtFlag"
        Me.txtFlag.Size = New System.Drawing.Size(180, 20)
        Me.txtFlag.TabIndex = 10
        '
        'txtHigh
        '
        Me.txtHigh.Location = New System.Drawing.Point(15, 540)
        Me.txtHigh.Name = "txtHigh"
        Me.txtHigh.Size = New System.Drawing.Size(180, 20)
        Me.txtHigh.TabIndex = 11
        '
        'grdJudges
        '
        Me.grdJudges.FixedCols = 1
        Me.grdJudges.FixedRows = 1
        Me.grdJudges.Location = New System.Drawing.Point(12, 266)
        Me.grdJudges.Name = "grdJudges"
        Me.grdJudges.Rows = 8
        Me.grdJudges.Scrollbars = System.Windows.Forms.ScrollBars.Both
        Me.grdJudges.Size = New System.Drawing.Size(220, 150)
        Me.grdJudges.TabIndex = 12
        '
        'frmGrillMealScore
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 580)
        Me.Controls.Add(Me.grdJudges)
        Me.Controls.Add(Me.txtHigh)
        Me.Controls.Add(Me.txtFlag)
        Me.Controls.Add(Me.txtOverallJ)
        Me.Controls.Add(Me.btnHighChef)
        Me.Controls.Add(Me.btnFlag)
        Me.Controls.Add(Me.btnOverallAvgJ)
        Me.Controls.Add(Me.btnRate)
        Me.Controls.Add(Me.btnAvgJudge)
        Me.Controls.Add(Me.btnAvgChef)
        Me.Controls.Add(Me.btnCaptData)
        Me.Controls.Add(Me.grdGrillMealScore)
        Me.Name = "frmGrillMealScore"
        Me.Text = "Grill Meal Scores"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents grdGrillMealScore As UJGrid.UJGrid
    Friend WithEvents btnCaptData As Button
    Friend WithEvents btnAvgChef As Button
    Friend WithEvents btnAvgJudge As Button
    Friend WithEvents btnRate As Button
    Friend WithEvents btnOverallAvgJ As Button
    Friend WithEvents btnFlag As Button
    Friend WithEvents btnHighChef As Button
    Friend WithEvents txtOverallJ As TextBox
    Friend WithEvents txtFlag As TextBox
    Friend WithEvents txtHigh As TextBox
    Friend WithEvents grdJudges As UJGrid.UJGrid
End Class
