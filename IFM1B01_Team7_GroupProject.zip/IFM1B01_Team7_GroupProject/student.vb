﻿' *****************************************************************
' Team Number: 7
' Team Member 1 Details: Mayet, AA (222001975)
' Team Member 2 Details: Ross, CR (222016699)
' Team Member 3 Details: Mabatha, TC (222107004)
' Team Member 4 Details: Ashimwe, HE (222127212)
' Practical: Team 7 Project
' Class name: Student
' *****************************************************************

Option Strict On
Option Explicit On
Option Infer Off

'Child class of person
Public Class Student

    Inherits Person
    Private _Grade As Integer
    Private _Disbled As Boolean
    Private _FeedingScheme As Boolean
    Private _Cost As Double

    'Constructor
    Public Sub New(Name As String, ID As String, Age As Integer, Grade As Integer, Disabled As Boolean, FeedingScheme As Boolean)
        MyBase.New(Name, ID, Age)
        _Grade = Grade
        _Disbled = Disabled
        _FeedingScheme = FeedingScheme
    End Sub

    'Property
    Public Property Grade As Integer
        Get
            Return _Grade
        End Get
        Set(value As Integer)
            _Grade = value
        End Set
    End Property

    Public Property Disabled As Boolean
        Get
            Return _Disbled
        End Get
        Set(value As Boolean)
            _Disbled = value
        End Set
    End Property

    Public Property FeedingScheme As Boolean
        Get
            Return _FeedingScheme
        End Get
        Set(value As Boolean)
            _FeedingScheme = value
        End Set
    End Property

    Public ReadOnly Property Cost As Double
        Get
            CalcCostOfPerson()
            Return _Cost
        End Get
    End Property

    'Method
    Public Overrides Sub CalcCostOfPerson()
        _Cost = 10000

        If _FeedingScheme Then
            _Cost += (365 * 75)
        End If

        If _Disbled Then
            _Cost += 15000
        End If
    End Sub

End Class
