﻿'Surname and initials: Mayet,AA
'Student number: 222001975
'Practical: 04

Option Explicit On
Option Infer Off
Option Strict On

Public Class Puppy

    Private _Name As String
    Private _Breed As String
    Private _Gender As String
    Private _Age As Integer
    Private _Weight() As Integer

    Public Sub New(days As Integer)
        ReDim _Weight(days)
    End Sub

    Public Property Name() As String
        Get
            Return _Name
        End Get
        Set(value As String)
            _Name = value
        End Set
    End Property

    Public Property Breed() As String
        Get
            Return _Breed
        End Get
        Set(value As String)
            _Breed = value
        End Set
    End Property

    Public Property Gender() As String
        Get
            Return _Gender
        End Get
        Set(value As String)
            _Gender = value
        End Set
    End Property

    Public Property Age As Integer
        Get
            Return _Age
        End Get
        Set(value As Integer)
            _Age = value
        End Set
    End Property

    Public Sub ResizeArray(days As Integer)
        ReDim Preserve _Weight(days)
    End Sub

    Public Property Weight(index As Integer) As Integer
        Get
            Return _Weight(index)
        End Get
        Set(value As Integer)
            _Weight(index) = value
        End Set
    End Property

    Public Function FoodFed(index As Integer) As Integer

        Dim count As Integer
        Dim w As Integer
        w = _Weight(index)

        count = 0

        While w >= 500

            count += 1
            w = w - 500

        End While

        If w > 0 Then

            count += 1

        End If

        Return count * 10

    End Function

End Class
