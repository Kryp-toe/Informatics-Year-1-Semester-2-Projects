﻿'*****************************************************************
' Team Number: 7
' Team Member 1 Details: Mayet, AA (222001975)
' Team Member 2 Details: Ross, CR (222016699)
' Team Member 3 Details: Mabatha, TC (222107004)
' Team Member 4 Details: Ashimwe, HE (222127212)
' Practical: Team 7 Project
' Class name: Form1
'*****************************************************************

Option Strict On
Option Explicit On
Option Infer Off

Public Class frmPrimarySchoolBudgetControlSystem

    Public NumSchools As Integer = 0
    Public Schools() As School

    'Sub for displaying text on the UJ grid
    Private Sub DispGrid(ByVal c As Integer, ByVal r As Integer, ByVal t As String)
        grdMain.Col = c
        grdMain.Row = r
        grdMain.Text = t
    End Sub

    'Sub fr setting up the UJ grid
    Private Sub SetUpGrid(ByVal C As Integer, ByVal R As Integer)
        grdMain.Cols = C
        grdMain.Rows = R
    End Sub

    Private Sub Main_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        SetUpGrid(7, 1)
        DispGrid(0, 0, "School Name")
        DispGrid(1, 0, "Adress")
        DispGrid(2, 0, "Number of Students")
        DispGrid(3, 0, "Number of Teachers")
        DispGrid(4, 0, "Watchlist Rank")
        DispGrid(5, 0, "Percentage Disabled")
        DispGrid(6, 0, "Estimated Yearly Budget")

    End Sub

    Private Sub btnAddSchool_Click(sender As Object, e As EventArgs) Handles btnAddSchool.Click

        'Add 1 to total number of schools
        NumSchools += 1

        'Resize the array
        ReDim Preserve Schools(NumSchools)

        Dim name As String
        Dim adress As String
        Dim attendence As Double

        name = InputBox("What is the name of the School?")
        adress = InputBox("What is the adress of " & name & " ?")
        attendence = CDbl(InputBox("What is the attendence percentage for " & name))

        'Makes all letters of name uppercase
        name = name.ToUpper()

        'Create the object school
        Schools(NumSchools) = New School(name, adress, attendence)

        'Add School to Combobox
        cmbSelectedSchool.Items.Add(name)

        'Display all the schools
        SetUpGrid(2, NumSchools + 1)
        DispGrid(0, 0, "School Name")
        DispGrid(1, 0, "Adress")
        Dim s As Integer
        For s = 1 To NumSchools
            DispGrid(0, s, Schools(s).Name)
            DispGrid(1, s, Schools(s).Address)
        Next

    End Sub

    Private Sub btnAddStudent_Click(sender As Object, e As EventArgs) Handles btnAddStudent.Click

        'get the following:
        Dim name As String
        Dim ID As String
        Dim age As Integer
        Dim grade As Integer
        Dim disabled As Boolean
        Dim feedingscheme As Boolean

        name = txtSName.Text
        ID = txtSID.Text
        age = CInt(txtSAge.Text)
        grade = CInt(txtSGrade.Text)

        disabled = CBool(cbDisabled.Text)
        feedingscheme = CBool(cbFeedingScheme.Text)

        Dim choice As String
        choice = cmbSelectedSchool.Text

        'Find the school
        Dim add As Integer
        Dim s As Integer
        For s = 1 To NumSchools
            If choice = Schools(s).Name Then
                add = s
            End If
        Next

        'Sub ceates object as well as upcasts
        Schools(add).AddStudent(name, ID, age, grade, disabled, feedingscheme)

        Dim objStudent As Student
        Dim peopletotal As Integer = Schools(add).NumStudents + Schools(add).NumTeachers
        Dim peoplecount As Integer
        Dim studentcount As Integer = 0

        SetUpGrid(6, Schools(add).NumStudents + 1)
        DispGrid(0, 0, "Student Name")
        DispGrid(1, 0, "ID Number")
        DispGrid(2, 0, "Age")
        DispGrid(3, 0, "Grade")
        DispGrid(4, 0, "Disabled")
        DispGrid(5, 0, "Feeding Scheme")

        'Downcasting
        For peoplecount = 1 To peopletotal
            objStudent = TryCast(Schools(add).People(peoplecount), Student)

            'If objStudent is a student in that school then
            If Not (objStudent Is Nothing) Then

                'count the student
                studentcount += 1

                'Complete the costs calculation in sub (Polymorphism)
                objStudent.CalcCostOfPerson()

                DispGrid(0, studentcount, objStudent.Name)
                DispGrid(1, studentcount, objStudent.IDNumber)
                DispGrid(2, studentcount, CStr(objStudent.Age))
                DispGrid(3, studentcount, CStr(objStudent.Grade))
                DispGrid(4, studentcount, CStr(objStudent.Disabled))
                DispGrid(5, studentcount, CStr(objStudent.FeedingScheme))

            End If

        Next peoplecount

    End Sub

    Private Sub btnAddTeacher_Click(sender As Object, e As EventArgs) Handles btnAddTeacher.Click


        'get the following:
        Dim name As String
        Dim ID As String
        Dim age As Integer
        Dim years As Integer

        name = txtTName.Text
        ID = txtTID.Text
        age = CInt(txtTAge.Text)
        years = CInt(txtTYears.Text)

        Dim choice As String
        choice = cmbSelectedSchool.Text

        'Find the school
        Dim add As Integer
        Dim s As Integer
        For s = 1 To NumSchools

            If choice = Schools(s).Name Then
                add = s
            End If

        Next

        'Sub ceates object as well as upcasts
        Schools(add).AddTeacher(name, ID, age, years)

        'for every student
        Dim objTeacher As Teacher
        Dim peopletotal As Integer = Schools(add).NumStudents + Schools(add).NumTeachers
        Dim peoplecount As Integer
        Dim teachercount As Integer = 0

        SetUpGrid(4, Schools(add).NumTeachers + 1)
        DispGrid(0, 0, "Teacher Name")
        DispGrid(1, 0, "ID Number")
        DispGrid(2, 0, "Age")
        DispGrid(3, 0, "Years Teaching")

        'Downcasting
        For peoplecount = 1 To peopletotal
            objTeacher = TryCast(Schools(add).People(peoplecount), Teacher)

            'If objTeacher is a Teacher in that school then
            If Not (objTeacher Is Nothing) Then

                'count the teacher
                teachercount += 1

                'Complete the costs calculation in sub (Polymorphism)
                objTeacher.CalcCostOfPerson()

                DispGrid(0, teachercount, objTeacher.Name)
                DispGrid(1, teachercount, objTeacher.IDNumber)
                DispGrid(2, teachercount, CStr(objTeacher.Age))
                DispGrid(3, teachercount, CStr(objTeacher.TYears))

            End If

        Next peoplecount

    End Sub

    Public Sub DisplayAllSchools()
        'Set up the display for the schools
        SetUpGrid(7, NumSchools + 1)
        DispGrid(0, 0, "School Name")
        DispGrid(1, 0, "Adress")
        DispGrid(2, 0, "Number of Students")
        DispGrid(3, 0, "Number of Teachers")
        DispGrid(4, 0, "Watchlist Rank")
        DispGrid(5, 0, "Percentage Disabled")
        DispGrid(6, 0, "Estimated Yearly Budget")

        Dim s As Integer
        For s = 1 To NumSchools
            'Display all of the schools information
            DispGrid(0, s, Schools(s).Name)
            DispGrid(1, s, Schools(s).Address)
            DispGrid(2, s, CStr(Schools(s).NumStudents))
            DispGrid(3, s, CStr(Schools(s).NumTeachers))
            DispGrid(4, s, Schools(s).WatchlistRank)
            DispGrid(5, s, Format(Schools(s).PercentageDisabled, "0.00"))
            DispGrid(6, s, "R " & Format(Schools(s).EstimatedYearlyBudget, "0.00"))
        Next
    End Sub

    Private Sub btnSpecificSchool_Click(sender As Object, e As EventArgs) Handles btnSpecificSchool.Click

        DisplayAllSchools()

        Dim s As Integer
        For s = 1 To NumSchools
            If Schools(s).EstimatedYearlyBudget > 18000000 Then
                MsgBox(Schools(s).Name & "'s budget is high")
            End If
            If Schools(s).EstimatedYearlyBudget < 5000000 Then
                MsgBox(Schools(s).Name & "'s budget is low")
            End If
        Next s

    End Sub

    Private Sub btnStudent_Click(sender As Object, e As EventArgs) Handles btnStudent.Click

        DisplayAllSchools()

        'Get schools name
        Dim choice As String
        choice = InputBox("Which School's Students would you like to view? (Enter the school name from the list in grid)")

        'Makes all letters uppercase
        choice = choice.ToUpper()

        'Find the school
        Dim view As Integer
        Dim s As Integer
        For s = 1 To NumSchools

            If choice = Schools(s).Name Then
                view = s
            Else
                MsgBox("Please type name correctly")
            End If

        Next


        'Display the information on each student
        SetUpGrid(7, Schools(view).NumStudents + 1)
        DispGrid(0, 0, "Student Name")
        DispGrid(1, 0, "ID Number")
        DispGrid(2, 0, "Age")
        DispGrid(3, 0, "Grade")
        DispGrid(4, 0, "Disabled")
        DispGrid(5, 0, "Feeding Scheme")
        DispGrid(6, 0, "Estimated Costs")


        Dim objStudent As Student
        Dim peopletotal As Integer = Schools(view).NumStudents + Schools(view).NumTeachers
        Dim peoplecount As Integer
        Dim studentcount As Integer = 0

        'Downcasting
        For peoplecount = 1 To peopletotal
            objStudent = TryCast(Schools(view).People(peoplecount), Student)

            'If objStudent is a student in that school then
            If Not (objStudent Is Nothing) Then

                'count the student
                studentcount += 1

                'Complete the costs calculation in sub (Polymorphism)
                objStudent.CalcCostOfPerson()

                DispGrid(0, studentcount, objStudent.Name)
                DispGrid(1, studentcount, objStudent.IDNumber)
                DispGrid(2, studentcount, CStr(objStudent.Age))
                DispGrid(3, studentcount, CStr(objStudent.Grade))
                DispGrid(4, studentcount, CStr(objStudent.Disabled))
                DispGrid(5, studentcount, CStr(objStudent.FeedingScheme))
                DispGrid(6, studentcount, "R " & Format(objStudent.Cost, "0.00"))

            End If

        Next peoplecount

    End Sub

    Private Sub btnTeacher_Click(sender As Object, e As EventArgs) Handles btnTeacher.Click

        DisplayAllSchools()

        'Get schools name
        Dim choice As String
        choice = InputBox("Which School's Students would you like to view? (Enter the school name from the list in grid)")

        'Makes all letters uppercase
        choice = choice.ToUpper()

        'Find the school
        Dim view As Integer
        Dim s As Integer
        For s = 1 To NumSchools

            If choice = Schools(s).Name Then
                view = s
            Else
                MsgBox("Please type name correctly")
            End If

        Next


        'Display the information on each student
        SetUpGrid(5, Schools(view).NumTeachers + 1)
        DispGrid(0, 0, "Teacher Name")
        DispGrid(1, 0, "ID Number")
        DispGrid(2, 0, "Age")
        DispGrid(3, 0, "Years Teaching")
        DispGrid(4, 0, "Salary")


        Dim objTeacher As Teacher
        Dim peopletotal As Integer = Schools(view).NumStudents + Schools(view).NumTeachers
        Dim peoplecount As Integer
        Dim teachercount As Integer = 0

        'Downcasting
        For peoplecount = 1 To peopletotal
            objTeacher = TryCast(Schools(view).People(peoplecount), Teacher)

            'If objTeacher is a Teacher in that school then
            If Not (objTeacher Is Nothing) Then

                'count the teacher
                teachercount += 1

                'Complete the costs calculation in sub (Polymorphism)
                objTeacher.CalcCostOfPerson()

                DispGrid(0, teachercount, objTeacher.Name)
                DispGrid(1, teachercount, objTeacher.IDNumber)
                DispGrid(2, teachercount, CStr(objTeacher.Age))
                DispGrid(3, teachercount, CStr(objTeacher.TYears))
                DispGrid(4, teachercount, CStr(objTeacher.Salary))

            End If

        Next peoplecount

    End Sub

End Class