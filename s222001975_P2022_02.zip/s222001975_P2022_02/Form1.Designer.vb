﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmProblem2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnMaxRecursive = New System.Windows.Forms.Button()
        Me.btnMaxInteritive = New System.Windows.Forms.Button()
        Me.grdProblem2 = New UJGrid.UJGrid()
        Me.btnInitial = New System.Windows.Forms.Button()
        Me.txtMaxInteritive = New System.Windows.Forms.TextBox()
        Me.txtMaxRecursive = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'btnMaxRecursive
        '
        Me.btnMaxRecursive.Location = New System.Drawing.Point(12, 246)
        Me.btnMaxRecursive.Name = "btnMaxRecursive"
        Me.btnMaxRecursive.Size = New System.Drawing.Size(100, 23)
        Me.btnMaxRecursive.TabIndex = 0
        Me.btnMaxRecursive.Text = "Max (Recursive)"
        Me.btnMaxRecursive.UseVisualStyleBackColor = True
        '
        'btnMaxInteritive
        '
        Me.btnMaxInteritive.Location = New System.Drawing.Point(12, 217)
        Me.btnMaxInteritive.Name = "btnMaxInteritive"
        Me.btnMaxInteritive.Size = New System.Drawing.Size(100, 23)
        Me.btnMaxInteritive.TabIndex = 1
        Me.btnMaxInteritive.Text = "Max (Interitive)"
        Me.btnMaxInteritive.UseVisualStyleBackColor = True
        '
        'grdProblem2
        '
        Me.grdProblem2.FixedCols = 1
        Me.grdProblem2.FixedRows = 1
        Me.grdProblem2.Location = New System.Drawing.Point(12, 62)
        Me.grdProblem2.Name = "grdProblem2"
        Me.grdProblem2.Rows = 7
        Me.grdProblem2.Scrollbars = System.Windows.Forms.ScrollBars.Both
        Me.grdProblem2.Size = New System.Drawing.Size(220, 149)
        Me.grdProblem2.TabIndex = 2
        '
        'btnInitial
        '
        Me.btnInitial.Location = New System.Drawing.Point(12, 13)
        Me.btnInitial.Name = "btnInitial"
        Me.btnInitial.Size = New System.Drawing.Size(220, 43)
        Me.btnInitial.TabIndex = 3
        Me.btnInitial.Text = "Initiaize"
        Me.btnInitial.UseVisualStyleBackColor = True
        '
        'txtMaxInteritive
        '
        Me.txtMaxInteritive.Location = New System.Drawing.Point(118, 217)
        Me.txtMaxInteritive.Name = "txtMaxInteritive"
        Me.txtMaxInteritive.Size = New System.Drawing.Size(100, 20)
        Me.txtMaxInteritive.TabIndex = 4
        '
        'txtMaxRecursive
        '
        Me.txtMaxRecursive.Location = New System.Drawing.Point(118, 246)
        Me.txtMaxRecursive.Name = "txtMaxRecursive"
        Me.txtMaxRecursive.Size = New System.Drawing.Size(100, 20)
        Me.txtMaxRecursive.TabIndex = 5
        '
        'frmProblem2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(244, 282)
        Me.Controls.Add(Me.txtMaxRecursive)
        Me.Controls.Add(Me.txtMaxInteritive)
        Me.Controls.Add(Me.btnInitial)
        Me.Controls.Add(Me.grdProblem2)
        Me.Controls.Add(Me.btnMaxInteritive)
        Me.Controls.Add(Me.btnMaxRecursive)
        Me.Name = "frmProblem2"
        Me.Text = "Problem 2"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnMaxRecursive As Button
    Friend WithEvents btnMaxInteritive As Button
    Friend WithEvents grdProblem2 As UJGrid.UJGrid
    Friend WithEvents btnInitial As Button
    Friend WithEvents txtMaxInteritive As TextBox
    Friend WithEvents txtMaxRecursive As TextBox
End Class
