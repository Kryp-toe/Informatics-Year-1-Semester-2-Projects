﻿'********************************************************************************************* 
'  Surname, Initials:  Mayet, AA
'  Student Number:  222001975
'  Practical: P03 
'********************************************************************************************* 

Option Explicit On
Option Infer Off
Option Strict On

Public Class frmGolf

    '|Declare variables
    Private Players() As Player
    Private nPlayers As Integer
    Private nCourses As Integer

    'Set up grid
    Private Sub SetGrid(ByVal C As Integer, ByVal R As Integer)
        grdGolf.Rows = R
        grdGolf.Cols = C
    End Sub

    'Disp grid
    Private Sub DispGrid(ByVal c As Integer, ByVal r As Integer, ByVal t As String)
        grdGolf.Row = r
        grdGolf.Col = c
        grdGolf.Text = t
    End Sub

    Private Sub frmGolf_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        SetGrid(10, 10)
        DispGrid(0, 0, "Name")
        DispGrid(1, 0, "Handicap")
        DispGrid(2, 0, "Score")
        DispGrid(3, 0, "Average Score")
        DispGrid(4, 0, "Best")
        DispGrid(5, 0, "Worst")

    End Sub

    Private Sub btnInitial_Click(sender As Object, e As EventArgs) Handles btnInitial.Click

        'Get no players
        nPlayers = CInt(InputBox("How many players are there?"))
        'size class(aloowcate memory)
        ReDim Players(nPlayers)

        'No. courses
        nCourses = CInt(InputBox("How many courses are there?"))
        'Construct(memory) for each player and every array in each player
        Dim p As Integer
        For p = 1 To nPlayers
            Players(p) = New Player(nCourses)
        Next

        'Grid/disp
        SetGrid(nCourses + 5, nPlayers + 1)
        Dim c As Integer
        For c = 1 To nCourses
            DispGrid(1 + c, 0, "Score for Course " & c)
        Next
        DispGrid(0, 0, "Name")
        DispGrid(1, 0, "Handicap")
        DispGrid(nCourses + 2, 0, "Average Score")
        DispGrid(nCourses + 3, 0, "Best Score")
        DispGrid(nCourses + 4, 0, "Worst Score")

    End Sub

    Private Sub btnInput_Click(sender As Object, e As EventArgs) Handles btnInput.Click

        'Player name/handicap 
        Dim p As Integer
        For p = 1 To nPlayers

            Players(p).Name = InputBox("What is the name of player " & p & " ?")
            Players(p).Handicap = CInt(InputBox("What is the Handicap of " & Players(p).Name & " ?"))
            DispGrid(0, p, Players(p).Name)
            DispGrid(1, p, CStr(Players(p).Handicap))

        Next p

    End Sub

    Private Sub btnScore_Click(sender As Object, e As EventArgs) Handles btnScore.Click

        'Score per player per course
        Dim p As Integer
        For p = 1 To nPlayers

            Dim c As Integer
            For c = 1 To nCourses

                Players(p).Score(c) = CInt(InputBox("How much did " & Players(p).Name & " get for Course " & c))
                DispGrid(c + 1, p, CStr(Players(p).Score(c)))

            Next

        Next

    End Sub

    Private Sub btnAvg_Click(sender As Object, e As EventArgs) Handles btnAvg.Click

        'Use avg func in class
        Dim p As Integer
        Dim avg As Double

        For p = 1 To nPlayers
            avg = Players(p).AvgScore(nCourses)
            DispGrid(nCourses + 2, p, CStr(avg))

        Next

    End Sub

    Private Sub btnWoBe_Click(sender As Object, e As EventArgs) Handles btnWoBe.Click

        'use best/worst func in class
        Dim best As Integer
        Dim worst As Integer
        Dim p As Integer

        For p = 1 To nPlayers

            best = Players(p).BestFunc(nCourses)
            worst = Players(p).WorstFunc(nCourses)

            DispGrid(nCourses + 3, p, CStr(best))
            DispGrid(nCourses + 4, p, CStr(worst))

        Next

    End Sub

End Class