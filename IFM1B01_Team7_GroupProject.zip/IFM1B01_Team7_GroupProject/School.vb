﻿'*****************************************************************
' Team Number: 7
' Team Member 1 Details: Mayet, AA (222001975)
' Team Member 2 Details: Ross, CR (222016699)
' Team Member 3 Details: Mabatha, TC (222107004)
' Team Member 4 Details: Ashimwe, HE (222127212)
' Practical: Team 7 Project
' Class name: School
'*****************************************************************

Option Strict On
Option Explicit On
Option Infer Off

Public Class School
    Private _Name As String
    Private _Address As String
    Private _AttendancePercentage As Double 
    Private _People() As Person
    
    
    Private _NumTeachers As Integer
    Private _NumStudents As Integer
    
    Private _WatchListRank as string
    Private _PercentageDisabled As Double '//
    Private _StudentTeacherRatio As Double '//
    Private _EstimatedYearlyBudgetNeeded As Double

    'Constants (Bonus)
    Private Const DEFAULT_SCHOOLNAME As String = "SchoolNameNotGiven"
    Private Const DEFAULT_ADDRESS As String = "SchoolAddressNotGiven"
    Private Const DEFAULT_ATTENDANCE As Double = 0

    '<<constructors>>
    Public Sub New(SchoolName As String, Address As String, AttendancePercentage as double) 'Added Attendance Percentage because user is meant to give it
        _Name = SchoolName
        _Address = Address
        _AttendancePercentage = AttendancePercentage
    End Sub

    'Constructor Overloading With Default Values (Bonus)
    Public Sub New()
        _Name = DEFAULT_SCHOOLNAME
        _Address = DEFAULT_ADDRESS
        _AttendancePercentage = DEFAULT_ATTENDANCE
    End Sub

    '<<Properties>>
    Public Property Name() As String
        Get
            Return _Name
        End Get
        Set(value As String)
            _Name = value
        End Set
    End Property

    Public Property Address() As String
        Get
            Return _Address
        End Get
        Set(value As String)
            _Address = value
        End Set
    End Property

    Public Property People(index As Integer) As Person
        Get
            Return _People(index)
        End Get
        Set(value As Person)
            _People(index) = value
        End Set
    End Property

    Public ReadOnly Property NumTeachers() As Integer
        Get
             DetermineNumStudentsandTeachers()
            Return _NumTeachers
        End Get
    End Property

    Public ReadOnly Property NumStudents() As Integer
        Get
             DetermineNumStudentsandTeachers()
            Return _NumStudents
        End Get
    End Property

    Public Property AttendancePercentage() As Double
        Get
            Return _AttendancePercentage
        End Get
        Set(value As Double)
            _AttendancePercentage = value
        End Set
    End Property

    Public ReadOnly Property WatchlistRank() As String
        Get
            DetermineWatchRank()
            Return _WatchListRank
        End Get
    End Property

    'Readonly because you must calculated it based on number of disabled children, not given by user
    Public ReadOnly Property PercentageDisabled() As Double
        Get
            DeterminePercentageDisabled()
            Return _PercentageDisabled
        End Get
    End Property

    Public ReadOnly Property StudentTeacherRatio() As Double
        Get
            DetermineStudentTeacherRatio()
            Return _StudentTeacherRatio
        End Get
    End Property

    Public ReadOnly Property EstimatedYearlyBudget() As Double
        Get
            CalcEstimatedCost()
            Return _EstimatedYearlyBudgetNeeded
        End Get
    End Property


    '<<Methods>>
    'Add Student to Array of People
    Public Sub AddStudent(Name As String, IDNumber As String, Age As Integer, Grade As Integer, Disabled As Boolean, FeedingScheme As Boolean)

        _NumStudents += 1
        ReDim Preserve _People(_NumStudents + _NumTeachers)

        Dim NewStudent As Student = New Student(Name, IDNumber, Age, Grade, Disabled, FeedingScheme)
        _People(_NumStudents + _NumTeachers) = NewStudent 'Upcasting
    End Sub

    'Adds Teacher in a similar way to sstudent
    Public Sub AddTeacher(Name As String, IDNumber As String, Age As Integer, years As Integer)

        _NumTeachers += 1
        ReDim Preserve _People(_NumTeachers + _NumStudents)

        Dim NewTeacher As Teacher = New Teacher(Name, IDNumber, Age, years)
        _People(_NumStudents + _NumTeachers) = NewTeacher 'Upcasting
    End Sub

    'Detemine The Percentage of Students who are disabled
    Private Sub DeterminePercentageDisabled()

        DetermineNumStudentsandTeachers()
        Dim objStudent As Student
        Dim _NumDisabled As Integer = 0

        'Downcasting
        For k As Integer = 1 To _People.Length - 1
            objStudent = TryCast(People(k), Student)

            If Not (objStudent Is Nothing) Then

                If objStudent.Disabled Then
                    _NumDisabled += 1
                End If
            End If
        Next
        _PercentageDisabled = (_NumDisabled / _NumStudents) * 100
    End Sub


'Determines Watch Rank Based on Given Attendace Percentage
Private Sub DetermineWatchRank()
    'See which schools need to be monitored
        Select Case _AttendancePercentage
            Case > 85
                _WatchListRank = "A"
            Case 60 To 85
                _WatchListRank = "B"
            Case 50 To 60
                _WatchListRank = "C"
            Case < 50
                _WatchListRank = "D"
        End Select
    
end Sub

'Determine how many students and teachers there are
    Private Sub DetermineNumStudentsandTeachers()

        Dim objStudent As Student
        Dim objTeacher As Teacher

        _NumStudents = 0
        _NumTeachers = 0

        'Downcasting
        For k As Integer = 1 To _People.Length - 1

            objStudent = TryCast(People(k), Student)

            If Not (objStudent Is Nothing) Then
                _NumStudents += 1
            End If

            objTeacher = TryCast(People(k), Teacher)

            If Not (objTeacher Is Nothing) Then
                _NumTeachers += 1
            End If
        Next
    End Sub

    'Determine Ratio Between Students and Teachers   
    Private Sub DetermineStudentTeacherRatio()
        DetermineNumStudentsandTeachers()
        _StudentTeacherRatio = _NumStudents / _NumTeachers
    End Sub

'Subroutine that adds up calculated cost of the students and teachers in the school and adds ontop based on the STRatio and PercentageDisabled
    Private Sub CalcEstimatedCost()

        Dim objStudent As Student
        Dim objTeacher As Teacher

        _EstimatedYearlyBudgetNeeded = 0

        'Call utility methods
        DetermineNumStudentsandTeachers()
        DetermineStudentTeacherRatio()
        DeterminePercentageDisabled()
        DetermineWatchRank()

        'Find total cost of both students and teachers
        For k As Integer = 1 To _People.Length - 1

            objStudent = TryCast(People(k), Student)

            If Not (objStudent Is Nothing) Then
                objStudent.CalcCostOfPerson()
                _EstimatedYearlyBudgetNeeded += objStudent.Cost
            End If

            objTeacher = TryCast(People(k), Teacher)

            If Not (objTeacher Is Nothing) Then
                objTeacher.CalcCostOfPerson()
                _EstimatedYearlyBudgetNeeded += objTeacher.Salary
            End If

        Next

        'Calc Cost Given for STRatio
        Select Case _StudentTeacherRatio
            Case > 30
                _EstimatedYearlyBudgetNeeded += 50000
            Case 20 To 30
                _EstimatedYearlyBudgetNeeded += 25000
            Case < 20
                _EstimatedYearlyBudgetNeeded += 10000
        End Select

        'Calc Cost from Disablities
        Select Case _PercentageDisabled
            Case > 25
                _EstimatedYearlyBudgetNeeded += 5000
            Case 5 To 25
                _EstimatedYearlyBudgetNeeded += 2500
            Case < 5
                _EstimatedYearlyBudgetNeeded += 1000
        End Select

    End Sub

End Class
