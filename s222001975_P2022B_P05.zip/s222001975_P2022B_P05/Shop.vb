﻿'*********************************************************************************************
' Surname, Initials: Mayet, AA
' Student Number: 222001975
' Practical: P05
'*********************************************************************************************

Option Explicit On
Option Infer Off
Option Strict On

Public Class Shop

    Private _ShopName As String
    Private _Numb As Integer
    Private _ContPers As String
    Private _ContTele As String
    Private _ContEmail As String
    Private _Items() As Item
    Private _nItem As Integer
    Private _AvgPrice As Double

    'Constructor for object
    Public Sub New(NumbItems As Integer, ShopName As String, Numb As Integer)

        _nItem = NumbItems
        _ShopName = ShopName
        _Numb = Numb

        'Size array
        ReDim _Items(_nItem)

    End Sub

    Public Property nItem As Integer
        Get
            Return _nItem
        End Get
        Set(value As Integer)
            _nItem = value
        End Set
    End Property

    Public Property Items(index As Integer) As Item
        Get
            Return _Items(index)
        End Get
        Set(value As Item)
            _Items(index) = value
        End Set
    End Property

    Public Property ShopName As String
        Get
            Return _ShopName
        End Get
        Set(value As String)
            _ShopName = value
        End Set
    End Property

    Public Property Numb As Integer
        Get
            Return _Numb
        End Get
        Set(value As Integer)
            _Numb = value
        End Set
    End Property

    Public Property ContPers As String
        Get
            Return _ContPers
        End Get
        Set(value As String)
            _ContPers = value
        End Set
    End Property

    Public Property ContTele As String
        Get
            Return _ContTele
        End Get
        Set(value As String)

            'first value = o 
            If value(0) = "0" Then
                'length of value is 10 characters
                If Len(value) = 10 Then
                    _ContTele = value
                End If

            Else

                'lenght of value is 12 charecters
                If Len(value) = 12 Then
                    'first 3 values are +27
                    If value(0) = "+" And value(1) = "2" And value(2) = "7" Then
                        _ContTele = value
                    End If
                End If

            End If

        End Set
    End Property

    Public Property ContEmail As String
        Get
            Return _ContEmail
        End Get
        Set(value As String)
            _ContEmail = value
        End Set
    End Property

    Public Property AvgPrice As Double
        Get
            Return _AvgPrice
        End Get
        Set(value As Double)
            _AvgPrice = value
        End Set
    End Property

    Public Function CalcAvgPrice() As Double

        Dim i As Integer
        Dim total As Integer
        For i = 1 To nItem
            total += _Items(i).Price
        Next
        Return total / nItem

    End Function

End Class
