﻿' *********************************************************************************
' Surname, Initials: Mayet, AA
' Student Number: 222001975
' Practical: P2022-09
' Class/Interface name: Wildlife
' *********************************************************************************

Option Infer Off
Option Strict On
Option Explicit On

<Serializable()> Public MustInherit Class Wildlife

    Private _TrackerID As String
    Private _RatingLEvel As Integer
    Private _Sightings() As Integer
    Private _Months As Integer
    Private _LeastMonth As Integer

    'Constructor
    Public Sub New(id As String, level As Integer, months As Integer)
        _TrackerID = id
        _RatingLEvel = level
        _Months = months
        ReDim Preserve _Sightings(months)
    End Sub

    'Property
    Public Property Sightings(index As Integer) As Integer
        Get
            Return _Sightings(index)
        End Get
        Set(value As Integer)
            _Sightings(index) = value
        End Set
    End Property

    'Methods
    Public Function CalcAvg() As Double

        Dim s As Integer
        Dim total As Integer

        For s = 1 To _Months
            total += _Sightings(s)
        Next

        Return total / _Months

    End Function

    Public Function LowestSighting() As Integer

        Dim s As Integer
        _LeastMonth = _Sightings(1)

        For s = 2 To _Months
            If _LeastMonth < _Sightings(s) Then
                _LeastMonth = _Sightings(s)
            End If
        Next

        Return _LeastMonth

    End Function

    Public Overridable Function CalcRarityRating() As String

        Dim rating As String
        Dim avg As Double = CalcAvg()

        Select Case _RatingLEvel

            Case 1 Or 2
                If avg <= 15 Then
                    rating = "C"
                Else
                    rating = "D"
                End If

            Case 3
                If avg <= 15 Then
                    rating = "B"
                Else
                    rating = "C"
                End If

            Case 4 Or 5
                If avg <= 15 Then
                    rating = "A"
                Else
                    rating = "B"
                End If

        End Select

        Return rating

    End Function

    Public Overridable Function Display() As String
        _LeastMonth = LowestSighting()
        Return _TrackerID & " : " & _RatingLEvel & " / " & Format(CalcAvg(), "0.00") & " / " & _LeastMonth
    End Function

End Class
