﻿'*********************************************************************************************
' Surname, Initials: Mayet, AA
' Student Number: 222001975
' Practical: P07
'*********************************************************************************************

Option Explicit On
Option Infer Off
Option Strict On

<Serializable()> Public MustInherit Class Student

    Private _FullName As String
    Private _NumMarks As Integer
    Private _Marks() As Integer
    Private _Average As Double
    Private _Qualifies As Boolean

    'Constructor
    Public Sub New(fullname As String, nummarks As Integer)
        _FullName = fullname
        _NumMarks = nummarks
        ReDim Preserve _Marks(nummarks)
    End Sub

    'Property methods
    Public ReadOnly Property FullName() As String
        Get
            Return _FullName
        End Get
    End Property

    Public Property Marks(index As Integer) As Integer
        Get
            Return _Marks(index)
        End Get
        Set(value As Integer)
            If value > 0 Then
                _Marks(index) = value
            Else
                _Marks(index) = 0
            End If
        End Set
    End Property

    Public ReadOnly Property Average() As Double
        Get
            Return _Average
        End Get
    End Property

    Public ReadOnly Property Qualifies As Boolean
        Get
            Return _Qualifies
        End Get
    End Property

    'Sub to calc average
    Public Sub CalcAvg()

        Dim m As Integer
        Dim total As Integer

        For m = 1 To _Marks.Length - 1
            total += _Marks(m)
        Next m

        _Average = total / _NumMarks

        _Qualifies = EvaluateStudent()

    End Sub

    'Function to evaluate students
    Public Overridable Function EvaluateStudent() As Boolean
        Return True
    End Function

    'Functon to display student info
    Public Function Display() As String

        Return _FullName & " (" & CStr(_Average) & ")"

    End Function

End Class
