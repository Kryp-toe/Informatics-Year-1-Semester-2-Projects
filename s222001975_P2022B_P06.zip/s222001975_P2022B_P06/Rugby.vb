﻿'*********************************************************************************************
' Surname, Initials: Mayet, AA
' Student Number: 222001975
' Practical: P06
'*********************************************************************************************

Option Explicit On
Option Strict On
Option Infer Off

'Child class
Public Class Rugby

    Inherits Sport

    'Class constructor
    Public Sub New(NT As Integer)
        MyBase.New(NT)
    End Sub

    'Function to calculate score
    Public Overrides Function CalcScore(tries As Integer, conversion As Integer, penalties As Integer, dropgoal As Integer) As String
        Return CStr((tries * 5) + (conversion * 3) + (penalties * 3) + (dropgoal * 3))
    End Function

End Class
