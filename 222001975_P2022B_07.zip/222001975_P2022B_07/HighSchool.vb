﻿'*********************************************************************************************
' Surname, Initials: Mayet, AA
' Student Number: 222001975
' Practical: P07
'*********************************************************************************************

Option Explicit On
Option Infer Off
Option Strict On

<Serializable()> Public Class HighSchool

    Inherits Student
    Private _ExtraMural As Boolean
    Private _Prefect As Boolean

    'Constructor
    Public Sub New(fullname As String)
        MyBase.New(fullname, 3)
    End Sub

    'Property methods
    Public Property ExtraMural As Boolean
        Get
            Return _ExtraMural
        End Get
        Set(value As Boolean)
            _ExtraMural = value
        End Set
    End Property

    Public Property Prefect As Boolean
        Get
            Return _Prefect
        End Get
        Set(value As Boolean)
            _Prefect = value
        End Set
    End Property

    'Function to evaluate student
    Public Overrides Function EvaluateStudent() As Boolean

        If Average >= 80 Then
            Return MyBase.EvaluateStudent()
        End If

        If Average >= 70 Then

            If ExtraMural = True Then
                Return MyBase.EvaluateStudent()
            End If
            If Prefect = True Then
                Return MyBase.EvaluateStudent()
            End If

        End If

    End Function

End Class
