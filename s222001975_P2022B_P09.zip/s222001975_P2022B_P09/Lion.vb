﻿' *********************************************************************************
' Surname, Initials: Mayet, AA
' Student Number: 222001975
' Practical: P2022-09
' Class/Interface name: Lion
' *********************************************************************************

Option Infer Off
Option Strict On
Option Explicit On

Public Class Lion

    Inherits Wildlife
    Private _Pride As Integer
    Private _IsALpha As Boolean

    'Constructor
    Public Sub New(id As String, level As Integer, nummonths As Integer)
        MyBase.New(id, level, nummonths)
    End Sub

    'Property
    Public Property Pride As Integer
        Get
            Return _Pride
        End Get
        Set(value As Integer)
            _Pride = value
        End Set
    End Property

    Public Property IsAlpha As Boolean
        Get
            Return _IsALpha
        End Get
        Set(value As Boolean)
            _IsALpha = value
        End Set
    End Property

    'Method
    Public Overrides Function CalcRarityRating() As String
        Return "C"
    End Function

    Public Overrides Function Display() As String
        Return MyBase.Display() & " / " & CalcRarityRating() & " / " & _Pride & " / " & _IsALpha
    End Function

End Class
