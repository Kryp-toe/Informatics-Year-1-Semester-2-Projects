﻿'*********************************************************************************************
' Surname, Initials: Mayet, AA
' Student Number: 222001975
' Practical: P07
'*********************************************************************************************

Option Explicit On
Option Infer Off
Option Strict On

Imports System.IO
Imports System.Runtime.Serialization.Formatters.Binary

Public Class frmUtopianSocialGrantsDepartment

    Private NumStudents As Integer = 0
    Private Students() As Student
    Private MyFile As FileStream
    Private BF As BinaryFormatter
    Private Const FileName As String = "FILE_222001975_P2022_07.ipb"
    Private StudentItem() As Student

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        txtDisplay.Text = "Display"
    End Sub

    'Function to determain the value of a boolean
    Public Function DetBoolean(name As String) As Boolean

        Dim choice As Integer

        choice = CInt(InputBox("Was the user part of " & name & vbNewLine & " 1. Yes " & vbNewLine & " 2. No "))

        Select Case choice
            Case 1
                Return True
            Case 2
                Return False
        End Select

    End Function

    Private Sub btnAddStudent_Click(sender As Object, e As EventArgs) Handles btnAddStudent.Click

        'Resize array
        NumStudents += 1
        ReDim Preserve Students(NumStudents)

        Dim choice As Integer
        choice = CInt(InputBox("Would you like to add a University or High School Student?" & vbNewLine & "1. High School" & vbNewLine & "2. University"))

        Select Case choice

            'High school
            Case 1

                Dim objHighSchool As HighSchool
                Dim name As String

                name = InputBox("What is the name of this High School Student?")

                'Create object
                objHighSchool = New HighSchool(name)

                'Upcast
                Students(NumStudents) = objHighSchool

                objHighSchool.ExtraMural = DetBoolean("Extra Mural")
                objHighSchool.Prefect = DetBoolean("Prefect")

                Dim m As Integer
                For m = 1 To 3
                    objHighSchool.Marks(m) = CInt(InputBox("How much did " & name & " get for mark " & m))
                Next

            'UNiversity
            Case 2

                Dim objUniversity As University
                Dim name As String

                name = InputBox("What is the name of this University Student?")

                'Create object
                objUniversity = New University(name)

                'Upcast
                Students(NumStudents) = objUniversity

                Dim m As Integer
                For m = 1 To 2
                    objUniversity.Marks(m) = CInt(InputBox("How much did " & name & " get for mark " & m))
                Next


            Case Else

                MsgBox("Please enter a valid response")

        End Select

    End Sub

    Private Sub btnAverage_Click(sender As Object, e As EventArgs) Handles btnAverage.Click

        Dim s As Integer
        For s = 1 To NumStudents

            'Polymorphism
            Students(s).CalcAvg()

        Next

        Dim choice As Integer
        choice = CInt(InputBox("Would you like to view the average marks for a University or High School Student?" & vbNewLine & "1. High School" & vbNewLine & "2. University"))

        txtDisplay.Text = ""

        Select Case choice

            'High School
            Case 1

                For s = 1 To NumStudents

                    'Downcasting
                    Dim objHighSchool As HighSchool
                    objHighSchool = TryCast(Students(s), HighSchool)

                    If Not (objHighSchool Is Nothing) Then

                        txtDisplay.Text &= objHighSchool.Display() & vbNewLine

                    End If

                Next

            'University
            Case 2

                For s = 1 To NumStudents

                    'Downcast
                    Dim objUniversity As University
                    objUniversity = TryCast(Students(s), University)

                    If Not (objUniversity Is Nothing) Then

                        txtDisplay.Text &= objUniversity.Display() & vbNewLine

                    End If

                Next

            Case Else

                MsgBox("Please enter a valid response")

        End Select


    End Sub

    Private Sub btnSaveToFile_Click(sender As Object, e As EventArgs) Handles btnSaveToFile.Click

        'Size array
        ReDim Preserve StudentItem(NumStudents)

        'Create file
        MyFile = New FileStream(FileName, FileMode.Create, FileAccess.ReadWrite)
        BF = New BinaryFormatter()

        'Save items to file
        Dim s As Integer
        For s = 1 To NumStudents
            StudentItem(s) = TryCast(Students(s), Student)

            If Not (StudentItem(s) Is Nothing) Then
                BF.Serialize(MyFile, StudentItem(s))
            End If

        Next

        MyFile.Close()

        MsgBox("Your file has been saved")

    End Sub

    Private Sub btnHighestAvg_Click(sender As Object, e As EventArgs) Handles btnHighestAvg.Click

        'Open file
        MyFile = New FileStream(FileName, FileMode.Open, FileAccess.ReadWrite)
        BF = New BinaryFormatter()

        Dim s As Integer
        Dim numqualify As Integer = 0
        Dim highest As Double = 0
        Dim name As String

        'Go through all items in file
        While MyFile.Position < MyFile.Length
            Dim tempstudent(NumStudents) As Student

            'Deserialize items
            For s = 1 To NumStudents
                tempstudent(s) = DirectCast(BF.Deserialize(MyFile), Student)

                'Get numb of students that qualified
                If StudentItem(s).Qualifies = True Then

                    numqualify += 1

                    'Find highest average
                    If highest < StudentItem(s).Average Then

                        'Det students info and display
                        highest = StudentItem(s).Average
                        name = Students(s).FullName

                        Dim total As Double
                        total = (175000 / numqualify) + 10000
                        txtHighest.Text = Students(s).FullName & " (" & StudentItem(s).Average & " ) = R" & Format(total, "0.00")

                    End If

                End If

            Next

        End While

        MyFile.Close()

    End Sub

End Class
