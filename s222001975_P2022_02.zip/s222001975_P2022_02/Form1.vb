﻿' *********************************************************************************
' Surname, Initials: Mayet, AA
' Student Number: 222001975
' Practical: P02
' Class name: frmProblem2
' *********************************************************************************

Option Explicit On
Option Infer Off
Option Strict On

Public Class frmProblem2

    'Declare variables
    Private array() As Double
    Private nArray As Integer
    Private max As Double
    Private maxRecur As Double

    Private Sub DispGrid(ByVal c As Integer, ByVal r As Integer, ByVal t As String)
        grdProblem2.Row = r
        grdProblem2.Col = c
        grdProblem2.Text = t
    End Sub

    Private Sub SetGrid(ByVal C As Integer, ByVal R As Integer)
        grdProblem2.Cols = C
        grdProblem2.Rows = R
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        SetGrid(2, 8)
        DispGrid(0, 0, "No.")
        DispGrid(1, 0, "Value")

    End Sub

    Private Sub btnInitial_Click(sender As Object, e As EventArgs) Handles btnInitial.Click

        'Get number of no. and resize array
        nArray = CInt(InputBox("How many numbers are you going to record?"))
        ReDim array(nArray)

        SetGrid(2, nArray + 1)

        Dim n As Integer
        For n = 1 To nArray

            'Get value of numbers
            array(n) = CDbl(InputBox("What is the value of number " & n))
            DispGrid(1, n, CStr(array(n)))
            DispGrid(0, n, CStr(n))

        Next

    End Sub

    Private Sub btnMaxInteritive_Click(sender As Object, e As EventArgs) Handles btnMaxInteritive.Click

        'Determain max
        max = array(1)

        Dim n As Integer
        For n = 2 To nArray

            If max < array(n) Then
                max = array(n)
            End If

            txtMaxInteritive.Text = CStr(max)

        Next

    End Sub

    Private Function FindMax(ByRef max As Double, x As Integer) As Double

        'Base case
        If x = 0 Then

            Return max

        Else

            'Determain max
            If max < array(x) Then
                max = array(x)
            End If

            'Recursive call
            Return FindMax(max, x - 1)

        End If

    End Function

    Private Sub btnMaxRecursive_Click(sender As Object, e As EventArgs) Handles btnMaxRecursive.Click

        'Call function
        maxRecur = FindMax(maxRecur, nArray)
        txtMaxRecursive.Text = CStr(maxRecur)

    End Sub

End Class
