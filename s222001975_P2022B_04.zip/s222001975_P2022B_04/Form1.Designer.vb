﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmSUPI
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.btnInitial = New System.Windows.Forms.Button()
        Me.bntInput = New System.Windows.Forms.Button()
        Me.btnFoodperPup = New System.Windows.Forms.Button()
        Me.btnTFoodCost = New System.Windows.Forms.Button()
        Me.grdSUPI = New UJGrid.UJGrid()
        Me.lblTotalFood = New System.Windows.Forms.Label()
        Me.lblTotalCost = New System.Windows.Forms.Label()
        Me.txtOverFood = New System.Windows.Forms.TextBox()
        Me.txtOverCost = New System.Windows.Forms.TextBox()
        Me.btnWeight = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btnInitial
        '
        Me.btnInitial.Location = New System.Drawing.Point(12, 12)
        Me.btnInitial.Name = "btnInitial"
        Me.btnInitial.Size = New System.Drawing.Size(135, 37)
        Me.btnInitial.TabIndex = 0
        Me.btnInitial.Text = "Initialize"
        Me.btnInitial.UseVisualStyleBackColor = True
        '
        'bntInput
        '
        Me.bntInput.Location = New System.Drawing.Point(153, 12)
        Me.bntInput.Name = "bntInput"
        Me.bntInput.Size = New System.Drawing.Size(135, 37)
        Me.bntInput.TabIndex = 1
        Me.bntInput.Text = "Input Data"
        Me.bntInput.UseVisualStyleBackColor = True
        '
        'btnFoodperPup
        '
        Me.btnFoodperPup.Location = New System.Drawing.Point(435, 12)
        Me.btnFoodperPup.Name = "btnFoodperPup"
        Me.btnFoodperPup.Size = New System.Drawing.Size(135, 37)
        Me.btnFoodperPup.TabIndex = 2
        Me.btnFoodperPup.Text = "Food per Puppy"
        Me.btnFoodperPup.UseVisualStyleBackColor = True
        '
        'btnTFoodCost
        '
        Me.btnTFoodCost.Location = New System.Drawing.Point(576, 12)
        Me.btnTFoodCost.Name = "btnTFoodCost"
        Me.btnTFoodCost.Size = New System.Drawing.Size(135, 37)
        Me.btnTFoodCost.TabIndex = 3
        Me.btnTFoodCost.Text = "Total Food and Cost"
        Me.btnTFoodCost.UseVisualStyleBackColor = True
        '
        'grdSUPI
        '
        Me.grdSUPI.FixedCols = 1
        Me.grdSUPI.FixedRows = 1
        Me.grdSUPI.Location = New System.Drawing.Point(12, 55)
        Me.grdSUPI.Name = "grdSUPI"
        Me.grdSUPI.Scrollbars = System.Windows.Forms.ScrollBars.Both
        Me.grdSUPI.Size = New System.Drawing.Size(699, 150)
        Me.grdSUPI.TabIndex = 4
        '
        'lblTotalFood
        '
        Me.lblTotalFood.AutoSize = True
        Me.lblTotalFood.Location = New System.Drawing.Point(12, 221)
        Me.lblTotalFood.Name = "lblTotalFood"
        Me.lblTotalFood.Size = New System.Drawing.Size(58, 13)
        Me.lblTotalFood.TabIndex = 5
        Me.lblTotalFood.Text = "Total Food"
        '
        'lblTotalCost
        '
        Me.lblTotalCost.AutoSize = True
        Me.lblTotalCost.Location = New System.Drawing.Point(12, 247)
        Me.lblTotalCost.Name = "lblTotalCost"
        Me.lblTotalCost.Size = New System.Drawing.Size(55, 13)
        Me.lblTotalCost.TabIndex = 6
        Me.lblTotalCost.Text = "Total Cost"
        '
        'txtOverFood
        '
        Me.txtOverFood.Location = New System.Drawing.Point(76, 214)
        Me.txtOverFood.Name = "txtOverFood"
        Me.txtOverFood.Size = New System.Drawing.Size(100, 20)
        Me.txtOverFood.TabIndex = 7
        '
        'txtOverCost
        '
        Me.txtOverCost.Location = New System.Drawing.Point(76, 240)
        Me.txtOverCost.Name = "txtOverCost"
        Me.txtOverCost.Size = New System.Drawing.Size(100, 20)
        Me.txtOverCost.TabIndex = 8
        '
        'btnWeight
        '
        Me.btnWeight.Location = New System.Drawing.Point(294, 12)
        Me.btnWeight.Name = "btnWeight"
        Me.btnWeight.Size = New System.Drawing.Size(135, 37)
        Me.btnWeight.TabIndex = 9
        Me.btnWeight.Text = "Weight per Day"
        Me.btnWeight.UseVisualStyleBackColor = True
        '
        'frmSUPI
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(729, 267)
        Me.Controls.Add(Me.btnWeight)
        Me.Controls.Add(Me.txtOverCost)
        Me.Controls.Add(Me.txtOverFood)
        Me.Controls.Add(Me.lblTotalCost)
        Me.Controls.Add(Me.lblTotalFood)
        Me.Controls.Add(Me.grdSUPI)
        Me.Controls.Add(Me.btnTFoodCost)
        Me.Controls.Add(Me.btnFoodperPup)
        Me.Controls.Add(Me.bntInput)
        Me.Controls.Add(Me.btnInitial)
        Me.Name = "frmSUPI"
        Me.Text = "SUPI"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnInitial As Button
    Friend WithEvents bntInput As Button
    Friend WithEvents btnFoodperPup As Button
    Friend WithEvents btnTFoodCost As Button
    Friend WithEvents grdSUPI As UJGrid.UJGrid
    Friend WithEvents lblTotalFood As Label
    Friend WithEvents lblTotalCost As Label
    Friend WithEvents txtOverFood As TextBox
    Friend WithEvents txtOverCost As TextBox
    Friend WithEvents btnWeight As Button
End Class
