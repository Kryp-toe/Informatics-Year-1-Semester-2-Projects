﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmPrimarySchoolBudgetControlSystem
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.cmbSelectedSchool = New System.Windows.Forms.ComboBox()
        Me.btnAddSchool = New System.Windows.Forms.Button()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.cbFeedingScheme = New System.Windows.Forms.ComboBox()
        Me.cbDisabled = New System.Windows.Forms.ComboBox()
        Me.txtSAge = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.txtSGrade = New System.Windows.Forms.TextBox()
        Me.txtSID = New System.Windows.Forms.TextBox()
        Me.txtSName = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.btnAddStudent = New System.Windows.Forms.Button()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.txtTYears = New System.Windows.Forms.TextBox()
        Me.txtTID = New System.Windows.Forms.TextBox()
        Me.txtTAge = New System.Windows.Forms.TextBox()
        Me.txtTName = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.btnAddTeacher = New System.Windows.Forms.Button()
        Me.btnStudent = New System.Windows.Forms.Button()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.btnSpecificSchool = New System.Windows.Forms.Button()
        Me.btnTeacher = New System.Windows.Forms.Button()
        Me.grdMain = New UJGrid.UJGrid()
        Me.Panel2.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(25, 78)
        Me.Label12.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(310, 20)
        Me.Label12.TabIndex = 13
        Me.Label12.Text = "Add Student or Teacher to Specific School"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(25, 117)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(263, 15)
        Me.Label1.TabIndex = 12
        Me.Label1.Text = "Currently Adding Student or Teacher to School: "
        '
        'cmbSelectedSchool
        '
        Me.cmbSelectedSchool.FormattingEnabled = True
        Me.cmbSelectedSchool.Location = New System.Drawing.Point(384, 117)
        Me.cmbSelectedSchool.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.cmbSelectedSchool.Name = "cmbSelectedSchool"
        Me.cmbSelectedSchool.Size = New System.Drawing.Size(183, 24)
        Me.cmbSelectedSchool.TabIndex = 11
        '
        'btnAddSchool
        '
        Me.btnAddSchool.Location = New System.Drawing.Point(29, 15)
        Me.btnAddSchool.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnAddSchool.Name = "btnAddSchool"
        Me.btnAddSchool.Size = New System.Drawing.Size(229, 44)
        Me.btnAddSchool.TabIndex = 10
        Me.btnAddSchool.Text = "Add New School"
        Me.btnAddSchool.UseVisualStyleBackColor = True
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.cbFeedingScheme)
        Me.Panel2.Controls.Add(Me.cbDisabled)
        Me.Panel2.Controls.Add(Me.txtSAge)
        Me.Panel2.Controls.Add(Me.Label11)
        Me.Panel2.Controls.Add(Me.txtSGrade)
        Me.Panel2.Controls.Add(Me.txtSID)
        Me.Panel2.Controls.Add(Me.txtSName)
        Me.Panel2.Controls.Add(Me.Label10)
        Me.Panel2.Controls.Add(Me.Label9)
        Me.Panel2.Controls.Add(Me.Label8)
        Me.Panel2.Controls.Add(Me.Label7)
        Me.Panel2.Controls.Add(Me.Label2)
        Me.Panel2.Controls.Add(Me.btnAddStudent)
        Me.Panel2.Location = New System.Drawing.Point(339, 154)
        Me.Panel2.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(359, 262)
        Me.Panel2.TabIndex = 9
        '
        'cbFeedingScheme
        '
        Me.cbFeedingScheme.FormattingEnabled = True
        Me.cbFeedingScheme.Items.AddRange(New Object() {"True", "False"})
        Me.cbFeedingScheme.Location = New System.Drawing.Point(200, 183)
        Me.cbFeedingScheme.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.cbFeedingScheme.Name = "cbFeedingScheme"
        Me.cbFeedingScheme.Size = New System.Drawing.Size(132, 24)
        Me.cbFeedingScheme.TabIndex = 18
        '
        'cbDisabled
        '
        Me.cbDisabled.FormattingEnabled = True
        Me.cbDisabled.Items.AddRange(New Object() {"True", "False"})
        Me.cbDisabled.Location = New System.Drawing.Point(200, 150)
        Me.cbDisabled.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.cbDisabled.Name = "cbDisabled"
        Me.cbDisabled.Size = New System.Drawing.Size(132, 24)
        Me.cbDisabled.TabIndex = 17
        '
        'txtSAge
        '
        Me.txtSAge.Location = New System.Drawing.Point(200, 55)
        Me.txtSAge.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txtSAge.Name = "txtSAge"
        Me.txtSAge.Size = New System.Drawing.Size(132, 22)
        Me.txtSAge.TabIndex = 16
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(16, 52)
        Me.Label11.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(37, 17)
        Me.Label11.TabIndex = 15
        Me.Label11.Text = "Age:"
        '
        'txtSGrade
        '
        Me.txtSGrade.Location = New System.Drawing.Point(200, 116)
        Me.txtSGrade.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txtSGrade.Name = "txtSGrade"
        Me.txtSGrade.Size = New System.Drawing.Size(132, 22)
        Me.txtSGrade.TabIndex = 12
        '
        'txtSID
        '
        Me.txtSID.Location = New System.Drawing.Point(200, 87)
        Me.txtSID.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txtSID.Name = "txtSID"
        Me.txtSID.Size = New System.Drawing.Size(132, 22)
        Me.txtSID.TabIndex = 11
        '
        'txtSName
        '
        Me.txtSName.Location = New System.Drawing.Point(200, 23)
        Me.txtSName.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txtSName.Name = "txtSName"
        Me.txtSName.Size = New System.Drawing.Size(132, 22)
        Me.txtSName.TabIndex = 10
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(16, 89)
        Me.Label10.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(25, 17)
        Me.Label10.TabIndex = 9
        Me.Label10.Text = "ID:"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(9, 182)
        Me.Label9.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(137, 17)
        Me.Label9.TabIndex = 8
        Me.Label9.Text = "On Feeding Scheme"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(16, 148)
        Me.Label8.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(67, 17)
        Me.Label8.TabIndex = 7
        Me.Label8.Text = "Disabled "
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(16, 116)
        Me.Label7.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(52, 17)
        Me.Label7.TabIndex = 6
        Me.Label7.Text = "Grade:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(16, 25)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(49, 17)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "Name:"
        '
        'btnAddStudent
        '
        Me.btnAddStudent.Location = New System.Drawing.Point(91, 229)
        Me.btnAddStudent.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnAddStudent.Name = "btnAddStudent"
        Me.btnAddStudent.Size = New System.Drawing.Size(167, 28)
        Me.btnAddStudent.TabIndex = 4
        Me.btnAddStudent.Text = "Add Student"
        Me.btnAddStudent.UseVisualStyleBackColor = True
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.txtTYears)
        Me.Panel1.Controls.Add(Me.txtTID)
        Me.Panel1.Controls.Add(Me.txtTAge)
        Me.Panel1.Controls.Add(Me.txtTName)
        Me.Panel1.Controls.Add(Me.Label6)
        Me.Panel1.Controls.Add(Me.Label5)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.btnAddTeacher)
        Me.Panel1.Location = New System.Drawing.Point(16, 154)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(315, 207)
        Me.Panel1.TabIndex = 8
        '
        'txtTYears
        '
        Me.txtTYears.Location = New System.Drawing.Point(168, 119)
        Me.txtTYears.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txtTYears.Name = "txtTYears"
        Me.txtTYears.Size = New System.Drawing.Size(132, 22)
        Me.txtTYears.TabIndex = 12
        '
        'txtTID
        '
        Me.txtTID.Location = New System.Drawing.Point(168, 90)
        Me.txtTID.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txtTID.Name = "txtTID"
        Me.txtTID.Size = New System.Drawing.Size(132, 22)
        Me.txtTID.TabIndex = 11
        '
        'txtTAge
        '
        Me.txtTAge.Location = New System.Drawing.Point(168, 59)
        Me.txtTAge.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txtTAge.Name = "txtTAge"
        Me.txtTAge.Size = New System.Drawing.Size(132, 22)
        Me.txtTAge.TabIndex = 10
        '
        'txtTName
        '
        Me.txtTName.Location = New System.Drawing.Point(168, 26)
        Me.txtTName.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txtTName.Name = "txtTName"
        Me.txtTName.Size = New System.Drawing.Size(132, 22)
        Me.txtTName.TabIndex = 7
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(19, 59)
        Me.Label6.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(37, 17)
        Me.Label6.TabIndex = 9
        Me.Label6.Text = "Age:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(19, 117)
        Me.Label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(112, 17)
        Me.Label5.TabIndex = 8
        Me.Label5.Text = "Years Teaching:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(19, 91)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(25, 17)
        Me.Label4.TabIndex = 7
        Me.Label4.Text = "ID:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(19, 27)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(45, 17)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "Name"
        '
        'btnAddTeacher
        '
        Me.btnAddTeacher.Location = New System.Drawing.Point(53, 172)
        Me.btnAddTeacher.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnAddTeacher.Name = "btnAddTeacher"
        Me.btnAddTeacher.Size = New System.Drawing.Size(167, 28)
        Me.btnAddTeacher.TabIndex = 3
        Me.btnAddTeacher.Text = "Add Teacher"
        Me.btnAddTeacher.UseVisualStyleBackColor = True
        '
        'btnStudent
        '
        Me.btnStudent.Location = New System.Drawing.Point(239, 320)
        Me.btnStudent.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnStudent.Name = "btnStudent"
        Me.btnStudent.Size = New System.Drawing.Size(172, 48)
        Me.btnStudent.TabIndex = 15
        Me.btnStudent.Text = "View Student From Scpecific School"
        Me.btnStudent.UseVisualStyleBackColor = True
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.grdMain)
        Me.Panel3.Controls.Add(Me.btnSpecificSchool)
        Me.Panel3.Controls.Add(Me.btnTeacher)
        Me.Panel3.Controls.Add(Me.btnStudent)
        Me.Panel3.Location = New System.Drawing.Point(705, 15)
        Me.Panel3.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(897, 399)
        Me.Panel3.TabIndex = 16
        '
        'btnSpecificSchool
        '
        Me.btnSpecificSchool.Location = New System.Drawing.Point(32, 320)
        Me.btnSpecificSchool.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnSpecificSchool.Name = "btnSpecificSchool"
        Me.btnSpecificSchool.Size = New System.Drawing.Size(172, 48)
        Me.btnSpecificSchool.TabIndex = 18
        Me.btnSpecificSchool.Text = "View Specific School"
        Me.btnSpecificSchool.UseVisualStyleBackColor = True
        '
        'btnTeacher
        '
        Me.btnTeacher.Location = New System.Drawing.Point(440, 320)
        Me.btnTeacher.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnTeacher.Name = "btnTeacher"
        Me.btnTeacher.Size = New System.Drawing.Size(172, 48)
        Me.btnTeacher.TabIndex = 16
        Me.btnTeacher.Text = "View Teacher From Scpecific School"
        Me.btnTeacher.UseVisualStyleBackColor = True
        '
        'grdMain
        '
        Me.grdMain.FixedCols = 1
        Me.grdMain.FixedRows = 1
        Me.grdMain.Location = New System.Drawing.Point(4, 4)
        Me.grdMain.Margin = New System.Windows.Forms.Padding(4)
        Me.grdMain.Name = "grdMain"
        Me.grdMain.Scrollbars = System.Windows.Forms.ScrollBars.Both
        Me.grdMain.Size = New System.Drawing.Size(889, 300)
        Me.grdMain.TabIndex = 19
        '
        'frmPrimarySchoolBudgetControlSystem
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1619, 432)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.cmbSelectedSchool)
        Me.Controls.Add(Me.btnAddSchool)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Name = "frmPrimarySchoolBudgetControlSystem"
        Me.Text = "Primary School Budget Control System"
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label12 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents cmbSelectedSchool As ComboBox
    Friend WithEvents btnAddSchool As Button
    Friend WithEvents Panel2 As Panel
    Friend WithEvents cbFeedingScheme As ComboBox
    Friend WithEvents cbDisabled As ComboBox
    Friend WithEvents txtSAge As TextBox
    Friend WithEvents Label11 As Label
    Friend WithEvents txtSGrade As TextBox
    Friend WithEvents txtSID As TextBox
    Friend WithEvents txtSName As TextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents btnAddStudent As Button
    Friend WithEvents Panel1 As Panel
    Friend WithEvents txtTYears As TextBox
    Friend WithEvents txtTID As TextBox
    Friend WithEvents txtTAge As TextBox
    Friend WithEvents txtTName As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents btnAddTeacher As Button
    Friend WithEvents btnStudent As Button
    Friend WithEvents Panel3 As Panel
    Friend WithEvents btnSpecificSchool As Button
    Friend WithEvents btnTeacher As Button
    Friend WithEvents grdMain As UJGrid.UJGrid
End Class
