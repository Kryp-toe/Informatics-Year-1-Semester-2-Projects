﻿'*********************************************************************************************
' Surname, Initials: Mayet, AA
' Student Number: 222001975
' Practical: P06
'*********************************************************************************************

Option Explicit On
Option Strict On
Option Infer Off

'Composition class, in sport(base class)
Public Class Team

    'Variables for each team
    Private _Name As String
    Private _nPleayers As Integer
    Private _Opponent As String
    Private _TeamScore As String
    Private _OppoScore As String

    'Class constructor
    Public Sub New(n As String, p As Integer, o As String)
        _Name = n
        _nPleayers = p
        _Opponent = o
    End Sub

    'Property methods
    Public Property nPlayers As Integer
        Get
            Return _nPleayers
        End Get
        Set(value As Integer)
            _nPleayers = value
        End Set
    End Property

    Public Property Name As String
        Get
            Return _Name
        End Get
        Set(value As String)
            _Name = value
        End Set
    End Property

    Public Property Opponent As String
        Get
            Return _Opponent
        End Get
        Set(value As String)
            _Opponent = value
        End Set
    End Property

    Public Property TeamScore As String
        Get
            Return _TeamScore
        End Get
        Set(value As String)
            _TeamScore = value
        End Set
    End Property

    Public Property OppoScore As String
        Get
            Return _OppoScore
        End Get
        Set(value As String)
            _OppoScore = value
        End Set
    End Property

End Class
