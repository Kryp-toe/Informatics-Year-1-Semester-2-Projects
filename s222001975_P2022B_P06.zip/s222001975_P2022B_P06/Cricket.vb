﻿'*********************************************************************************************
' Surname, Initials: Mayet, AA
' Student Number: 222001975
' Practical: P06
'*********************************************************************************************

Option Explicit On
Option Strict On
Option Infer Off

'Child class
Public Class Cricket

    Inherits Sport

    'Class conctructor
    Public Sub New(NT As Integer)
        MyBase.New(NT)
    End Sub

    'Function to calculate score
    Public Overrides Function CalcScore(runs As Integer, wickets As Integer, x As Integer, y As Integer) As String
        Return CStr(runs) & " / " & CStr(wickets)
    End Function

End Class
