﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmWildLifeTracker
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnSetUp = New System.Windows.Forms.Button()
        Me.btnDisplay = New System.Windows.Forms.Button()
        Me.btnDisplayFile = New System.Windows.Forms.Button()
        Me.btnSaveFile = New System.Windows.Forms.Button()
        Me.btnRating = New System.Windows.Forms.Button()
        Me.txtDisplayAll = New System.Windows.Forms.TextBox()
        Me.txtDisplayRhino = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'btnSetUp
        '
        Me.btnSetUp.Location = New System.Drawing.Point(16, 15)
        Me.btnSetUp.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnSetUp.Name = "btnSetUp"
        Me.btnSetUp.Size = New System.Drawing.Size(191, 33)
        Me.btnSetUp.TabIndex = 0
        Me.btnSetUp.Text = "Set Up"
        Me.btnSetUp.UseVisualStyleBackColor = True
        '
        'btnDisplay
        '
        Me.btnDisplay.Location = New System.Drawing.Point(215, 15)
        Me.btnDisplay.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnDisplay.Name = "btnDisplay"
        Me.btnDisplay.Size = New System.Drawing.Size(191, 33)
        Me.btnDisplay.TabIndex = 1
        Me.btnDisplay.Text = "Display"
        Me.btnDisplay.UseVisualStyleBackColor = True
        '
        'btnDisplayFile
        '
        Me.btnDisplayFile.Location = New System.Drawing.Point(215, 294)
        Me.btnDisplayFile.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnDisplayFile.Name = "btnDisplayFile"
        Me.btnDisplayFile.Size = New System.Drawing.Size(191, 33)
        Me.btnDisplayFile.TabIndex = 2
        Me.btnDisplayFile.Text = "Display File"
        Me.btnDisplayFile.UseVisualStyleBackColor = True
        '
        'btnSaveFile
        '
        Me.btnSaveFile.Location = New System.Drawing.Point(16, 294)
        Me.btnSaveFile.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnSaveFile.Name = "btnSaveFile"
        Me.btnSaveFile.Size = New System.Drawing.Size(191, 33)
        Me.btnSaveFile.TabIndex = 3
        Me.btnSaveFile.Text = "Save Rhino to File"
        Me.btnSaveFile.UseVisualStyleBackColor = True
        '
        'btnRating
        '
        Me.btnRating.Location = New System.Drawing.Point(413, 15)
        Me.btnRating.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnRating.Name = "btnRating"
        Me.btnRating.Size = New System.Drawing.Size(191, 33)
        Me.btnRating.TabIndex = 4
        Me.btnRating.Text = "Change Rating"
        Me.btnRating.UseVisualStyleBackColor = True
        '
        'txtDisplayAll
        '
        Me.txtDisplayAll.Location = New System.Drawing.Point(16, 55)
        Me.txtDisplayAll.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txtDisplayAll.Multiline = True
        Me.txtDisplayAll.Name = "txtDisplayAll"
        Me.txtDisplayAll.Size = New System.Drawing.Size(587, 192)
        Me.txtDisplayAll.TabIndex = 5
        '
        'txtDisplayRhino
        '
        Me.txtDisplayRhino.Location = New System.Drawing.Point(16, 335)
        Me.txtDisplayRhino.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txtDisplayRhino.Multiline = True
        Me.txtDisplayRhino.Name = "txtDisplayRhino"
        Me.txtDisplayRhino.Size = New System.Drawing.Size(587, 192)
        Me.txtDisplayRhino.TabIndex = 6
        '
        'frmWildLifeTracker
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(756, 677)
        Me.Controls.Add(Me.txtDisplayRhino)
        Me.Controls.Add(Me.txtDisplayAll)
        Me.Controls.Add(Me.btnRating)
        Me.Controls.Add(Me.btnSaveFile)
        Me.Controls.Add(Me.btnDisplayFile)
        Me.Controls.Add(Me.btnDisplay)
        Me.Controls.Add(Me.btnSetUp)
        Me.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Name = "frmWildLifeTracker"
        Me.Text = "Wildlife Tracker"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnSetUp As Button
    Friend WithEvents btnDisplay As Button
    Friend WithEvents btnDisplayFile As Button
    Friend WithEvents btnSaveFile As Button
    Friend WithEvents btnRating As Button
    Friend WithEvents txtDisplayAll As TextBox
    Friend WithEvents txtDisplayRhino As TextBox
End Class
