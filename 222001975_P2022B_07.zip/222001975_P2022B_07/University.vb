﻿'*********************************************************************************************
' Surname, Initials: Mayet, AA
' Student Number: 222001975
' Practical: P07
'*********************************************************************************************

Option Explicit On
Option Infer Off
Option Strict On

<Serializable()> Public Class University

    Inherits Student

    'Constructor
    Public Sub New(fullname As String)
        MyBase.New(fullname, 2)
    End Sub

    'Function to evaluate student
    Public Overrides Function EvaluateStudent() As Boolean

        If Average >= 65 Then
            Return MyBase.EvaluateStudent()
        End If

    End Function

End Class
