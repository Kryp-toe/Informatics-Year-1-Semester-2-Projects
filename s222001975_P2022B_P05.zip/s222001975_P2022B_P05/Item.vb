﻿'*********************************************************************************************
' Surname, Initials: Mayet, AA
' Student Number: 222001975
' Practical: P05
'*********************************************************************************************

Option Explicit On
Option Infer Off
Option Strict On

Public Class Item

    Private _ItemName As String
    Private _Category As String
    Private _Price As Integer

    'Constructor
    Public Sub New(ItemName As String, Category As String)

        _ItemName = ItemName
        _Category = Category

    End Sub

    Public Property ItemName As String
        Get
            Return _ItemName
        End Get
        Set(value As String)
            _ItemName = value
        End Set
    End Property

    Public Property Category As String
        Get
            Return _Category
        End Get
        Set(value As String)
            _Category = value
        End Set
    End Property

    Public Property Price As Integer
        Get
            Return _Price
        End Get
        Set(value As Integer)

            'Value must be more than 0
            If value > 0 Then
                _Price = value
            End If

        End Set
    End Property

End Class
