﻿'*********************************************************************************************
' Surname, Initials: Mayet, AA
' Student Number: 222001975
' Practical: P05
'*********************************************************************************************

Option Explicit On
Option Infer Off
Option Strict On

Public Class frmMall

    Private nShop As Integer
    Private Shops() As Shop
    Private TotalAvgPrice As Double

    'Load the form, label headings
    Private Sub frmMall_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        nShop = 0
        TotalAvgPrice = 0
        SetGridList(7, 8)
        SetGridShop(3, 8)
        DispGridList(0, 0, "Shop Number")
        DispGridList(1, 0, "Shop Name")
        DispGridList(2, 0, "Contact Person")
        DispGridList(3, 0, "Contact Number")
        DispGridList(4, 0, "Contact Email")
        DispGridList(5, 0, "Number of Items")
        DispGridList(6, 0, "Average Price")
        DispGridShop(0, 0, "Item name")
        DispGridShop(1, 0, "Item Category")
        DispGridShop(2, 0, "Item Price")
    End Sub

    'Subs for display onto grids
    Private Sub DispGridShop(ByVal c As Integer, ByVal r As Integer, ByVal t As String)
        grdShopItemInfo.Col = c
        grdShopItemInfo.Row = r
        grdShopItemInfo.Text = t
    End Sub

    Private Sub SetGridShop(ByVal C As Integer, ByVal R As Integer)
        grdShopItemInfo.Cols = C
        grdShopItemInfo.Rows = R
    End Sub

    Private Sub DispGridList(ByVal c As Integer, ByVal r As Integer, ByVal t As String)
        grdList.Col = c
        grdList.Row = r
        grdList.Text = t
    End Sub

    Private Sub SetGridList(ByVal C As Integer, ByVal R As Integer)
        grdList.Cols = C
        grdList.Rows = R
    End Sub

    Private Sub btnInitial_Click(sender As Object, e As EventArgs) Handles btnInitial.Click

        'get no. shops resize array
        nShop = CInt(InputBox("How many shops are there in in the mall?"))

        ReDim Shops(nShop)

        SetGridList(7, nShop + 1)

    End Sub

    Private Sub btnCapShop_Click(sender As Object, e As EventArgs) Handles btnCapShop.Click

        Dim s As Integer
        For s = 1 To nShop

            'Get shop details
            Dim Sname As String
            Dim numitem, numb As Integer

            numb = 543 + s
            Sname = InputBox("What is the Shop Name of " & numb)
            numitem = CInt(InputBox("How many items does " & Sname & " have?"))

            'display all information
            DispGridList(1, s, Sname)
            DispGridList(0, s, CStr(numb))
            DispGridList(5, s, CStr(numitem))

            'Create shop object
            Shops(s) = New Shop(numitem, Sname, numb)

            Shops(s).ContPers = InputBox("Who is the contact person for " & Sname)
            DispGridList(2, s, Shops(s).ContPers)
            Shops(s).ContTele = InputBox("What is the Telephone Number of the contact person for shop " & Sname)
            DispGridList(3, s, Shops(s).ContTele)
            Shops(s).ContEmail = InputBox("What is the Email for the contact person for " & Sname)
            DispGridList(4, s, Shops(s).ContEmail)

        Next s

    End Sub

    Private Sub btnCapItems_Click(sender As Object, e As EventArgs) Handles btnCapItems.Click

        Dim s As Integer
        For s = 1 To nShop

            'Get details of each item in each shop
            Dim i As Integer
            Dim numitem As Integer
            numitem = Shops(s).nItem
            For i = 1 To numitem

                Dim Iname, Category As String
                Iname = InputBox("What is the name of item " & i & " in shop " & Shops(s).ShopName)
                Category = InputBox("Whay is the category for " & Iname)

                'Create object item for each shop
                Shops(s).Items(i) = New Item(Iname, Category)

                Shops(s).Items(i).Price = CInt(InputBox("How much is " & Shops(s).Items(i).ItemName))

            Next i

            Shops(s).AvgPrice = Shops(s).CalcAvgPrice()
            DispGridList(6, s, CStr(Shops(s).AvgPrice))

        Next s

    End Sub

    Private Sub btnView_Click(sender As Object, e As EventArgs) Handles btnView.Click

        'Get shop no. user wants to view
        Dim snum As Integer
        Dim s As Integer
        Dim show As Integer
        snum = CInt(txtView.Text)

        'Det which shop the user wants to see
        For s = 1 To nShop
            If snum = Shops(s).Numb Then
                show = s
            End If
        Next

        'Show user all items and details of the shop
        Dim i As Integer
        For i = 1 To Shops(show).nItem

            SetGridShop(3, Shops(show).nItem + 1)
            DispGridShop(0, i, Shops(show).Items(i).ItemName)
            DispGridShop(1, i, Shops(show).Items(i).Category)
            DispGridShop(2, i, "R" & CStr(Shops(show).Items(i).Price))

        Next i

    End Sub

    Private Sub btnCalcAvg_Click(sender As Object, e As EventArgs) Handles btnCalcAvg.Click

        Dim s As Integer
        For s = 1 To nShop
            TotalAvgPrice += Shops(s).AvgPrice
        Next

        txtAvgPrice.Text = CStr(TotalAvgPrice)

    End Sub

End Class
