﻿'********************************************************************************************* '
'Surname, Initials: Mayet, AA
'Student Number: 222001975
'Practical: P01 
'********************************************************************************************* 

Option Explicit On
Option Infer Off
Option Strict On

Public Class frmGrillMealScore

    Private nChef As Integer
    Private nJudge As Integer
    Private Chef() As rChef
    Private Judge() As rJudge

    Private Structure rChef
        Public Name As String
        Public Dish As String
        Public AvgScoreChef As Double
        Public Rating As String
        Public Flag As String
    End Structure
    Private Structure rJudge
        Public ChefScore() As Integer
        Public TotalScore As Integer
        Public Average As Double
    End Structure

    Private Sub GridDisp(ByRef c As Integer, ByRef r As Integer, ByRef t As String)
        grdGrillMealScore.Row = r
        grdGrillMealScore.Col = c
        grdGrillMealScore.Text = t
    End Sub

    Private Sub SetGrid(ByRef C As Integer, ByRef R As Integer)
        grdGrillMealScore.Cols = C
        grdGrillMealScore.Rows = R
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        SetGrid(6, 1)
        GridDisp(0, 0, "Name")
        GridDisp(1, 0, "Dish")
        GridDisp(2, 0, "Judge Score")
        GridDisp(3, 0, "Average Score")
        GridDisp(4, 0, "Rating")
        GridDisp(5, 0, "Flagged?")

        grdJudges.Col = 0
        grdJudges.Row = 0
        grdJudges.Text = "Judge"

        grdJudges.Col = 1
        grdJudges.Row = 0
        grdJudges.Text = "Average Score"

    End Sub

    Private Sub btnCaptData_Click(sender As Object, e As EventArgs) Handles btnCaptData.Click

        nChef = CInt(InputBox("How many Chef's are there?"))
        nJudge = CInt(InputBox("How many Judges are their?"))

        SetGrid(5, nChef + 1)

        GridDisp(0, 0, "Name")
        GridDisp(1, 0, "Dish")
        GridDisp(2, 0, "Chef Average Score")
        GridDisp(3, 0, "Rating")
        GridDisp(4, 0, "Flagged?")

        grdJudges.Rows = nJudge + 1
        grdJudges.Cols = 2

        Dim row As Integer
        For row = 1 To nJudge
            grdJudges.Row = row
            grdJudges.Col = 0
            grdJudges.Text = "Judge " & row
        Next

        ReDim Chef(nChef)
        ReDim Judge(nJudge)
        Dim x As Integer
        For x = 1 To nJudge
            ReDim Judge(x).ChefScore(nChef)
        Next

        Dim c As Integer
        For c = 1 To nChef

            Chef(c).Name = InputBox("What is the name of chef " & c & "?")
            Chef(c).Dish = InputBox("What dish did chef " & Chef(c).Name & " make?")
            GridDisp(0, c, Chef(c).Name)
            GridDisp(1, c, Chef(c).Dish)

        Next

    End Sub

    Private Sub btnAvgChef_Click(sender As Object, e As EventArgs) Handles btnAvgChef.Click

        Dim c As Integer
        For c = 1 To nChef
            Chef(c).AvgScoreChef = 0

            Dim j As Integer
            Dim total As Integer
            total = 0
            For j = 1 To nJudge

                Judge(j).ChefScore(c) = CInt(InputBox("What is the score judge " & j & " give Chef " & Chef(c).Name & "?"))
                total += Judge(j).ChefScore(c)
                Judge(j).TotalScore += Judge(j).ChefScore(c)
                Chef(c).AvgScoreChef = total / nJudge
                GridDisp(2, c, CStr(Chef(c).AvgScoreChef))

            Next

        Next

    End Sub

    Private Sub btnAvgJudge_Click(sender As Object, e As EventArgs) Handles btnAvgJudge.Click


        Dim j As Integer
        Dim total As Integer
        total = 0
        For j = 1 To nJudge

            Judge(j).Average = Judge(j).TotalScore / nChef


            grdJudges.Row = j
            grdJudges.Col = 1
            grdJudges.Text = CStr(Judge(j).Average)

        Next

    End Sub

    Private Function DetermainRating(ByVal a As Double) As Integer

        Select Case a

            Case 0 To 2.5
                Return 4

            Case 2.6 To 5
                Return 3

            Case 5.1 To 7.5
                Return 2

            Case 7.6 To 10
                Return 1

        End Select

    End Function

    Private Sub btnRate_Click(sender As Object, e As EventArgs) Handles btnRate.Click

        Dim c As Integer
        For c = 1 To nChef

            Chef(c).Rating = CStr(DetermainRating(Chef(c).AvgScoreChef))
            GridDisp(3, c, Chef(c).Rating)

        Next

    End Sub

    Private Sub btnOverallAvgJ_Click(sender As Object, e As EventArgs) Handles btnOverallAvgJ.Click

        Dim c As Integer
        Dim total As Double
        Dim overallaverage As Double
        total = 0
        For c = 1 To nChef

            total += Chef(c).AvgScoreChef
            overallaverage = total / nChef
            txtOverallJ.Text = CStr(overallaverage)

        Next

    End Sub

    Private Sub btnFlag_Click(sender As Object, e As EventArgs) Handles btnFlag.Click

        Dim nflag As Integer
        Dim c As Integer
        nflag = 0
        For c = 1 To nChef

            If CDbl(Chef(c).Rating) <= 2 Then
                Chef(c).Flag = "Yes"
                nflag += 1
            Else
                Chef(c).Flag = "No"
            End If

            GridDisp(4, c, Chef(c).Flag)
            txtFlag.Text = CStr(nflag)

        Next

    End Sub

    Private Sub btnHighChef_Click(sender As Object, e As EventArgs) Handles btnHighChef.Click

        Dim max As Double
        Dim maxind As Integer
        Dim c As Integer

        maxind = 1

        For c = 2 To nChef
            max = Chef(maxind).AvgScoreChef

            If max < Chef(c).AvgScoreChef Then
                maxind = c
            End If

        Next

        txtHigh.Text = Chef(maxind).Name

    End Sub

End Class
