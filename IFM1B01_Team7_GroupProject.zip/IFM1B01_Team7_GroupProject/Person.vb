﻿'*****************************************************************
' Team Number: 7
' Team Member 1 Details: Mayet, AA (222001975)
' Team Member 2 Details: Ross, CR (222016699)
' Team Member 3 Details: Mabatha, TC (222107004)
' Team Member 4 Details: Ashimwe, HE (222127212)
' Practical: Team 7 Project
' Class name: Person
'*****************************************************************

Option Strict On
Option Explicit On
Option Infer Off

'Abstract class person
Public MustInherit Class Person

    Private _Name As String
    Private _IDNumber As String
    Private _Age As Integer

    'Constructer 
    Public Sub New(Name As String, ID As String, Age As Integer)

        _Name = Name
        _IDNumber = ID
        _Age = Age

    End Sub

    'Public properties  
    Public Property Name As String
        Get
            Return _Name
        End Get
        Set(value As String)
            _Name = value
        End Set
    End Property

    Public Property IDNumber As String
        Get
            Return _IDNumber
        End Get
        Set(value As String)
            _IDNumber = value
        End Set
    End Property

    Public Property Age As Integer
        Get
            Return _Age
        End Get
        Set(value As Integer)
            _Age = value
        End Set
    End Property

    'Method 
    Public MustOverride Sub CalcCostOfPerson()

End Class
