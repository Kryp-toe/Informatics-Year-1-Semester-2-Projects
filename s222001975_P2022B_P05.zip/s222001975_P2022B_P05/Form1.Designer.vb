﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMall
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.grdList = New UJGrid.UJGrid()
        Me.btnInitial = New System.Windows.Forms.Button()
        Me.btnCapShop = New System.Windows.Forms.Button()
        Me.btnCapItems = New System.Windows.Forms.Button()
        Me.btnCalcAvg = New System.Windows.Forms.Button()
        Me.btnView = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.grdShopItemInfo = New UJGrid.UJGrid()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtView = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtAvgPrice = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'grdList
        '
        Me.grdList.Cols = 7
        Me.grdList.FixedCols = 1
        Me.grdList.FixedRows = 1
        Me.grdList.Location = New System.Drawing.Point(12, 74)
        Me.grdList.Name = "grdList"
        Me.grdList.Rows = 8
        Me.grdList.Scrollbars = System.Windows.Forms.ScrollBars.Both
        Me.grdList.Size = New System.Drawing.Size(720, 127)
        Me.grdList.TabIndex = 0
        '
        'btnInitial
        '
        Me.btnInitial.Location = New System.Drawing.Point(12, 12)
        Me.btnInitial.Name = "btnInitial"
        Me.btnInitial.Size = New System.Drawing.Size(108, 35)
        Me.btnInitial.TabIndex = 1
        Me.btnInitial.Text = "Initialize"
        Me.btnInitial.UseVisualStyleBackColor = True
        '
        'btnCapShop
        '
        Me.btnCapShop.Location = New System.Drawing.Point(352, 12)
        Me.btnCapShop.Name = "btnCapShop"
        Me.btnCapShop.Size = New System.Drawing.Size(108, 35)
        Me.btnCapShop.TabIndex = 2
        Me.btnCapShop.Text = "Capture Shops"
        Me.btnCapShop.UseVisualStyleBackColor = True
        '
        'btnCapItems
        '
        Me.btnCapItems.Location = New System.Drawing.Point(624, 12)
        Me.btnCapItems.Name = "btnCapItems"
        Me.btnCapItems.Size = New System.Drawing.Size(108, 35)
        Me.btnCapItems.TabIndex = 3
        Me.btnCapItems.Text = "Capture Items"
        Me.btnCapItems.UseVisualStyleBackColor = True
        '
        'btnCalcAvg
        '
        Me.btnCalcAvg.Location = New System.Drawing.Point(383, 222)
        Me.btnCalcAvg.Name = "btnCalcAvg"
        Me.btnCalcAvg.Size = New System.Drawing.Size(91, 22)
        Me.btnCalcAvg.TabIndex = 4
        Me.btnCalcAvg.Text = "Calculate"
        Me.btnCalcAvg.UseVisualStyleBackColor = True
        '
        'btnView
        '
        Me.btnView.Location = New System.Drawing.Point(383, 248)
        Me.btnView.Name = "btnView"
        Me.btnView.Size = New System.Drawing.Size(91, 23)
        Me.btnView.TabIndex = 5
        Me.btnView.Text = "View"
        Me.btnView.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.Label1.Location = New System.Drawing.Point(12, 54)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(92, 17)
        Me.Label1.TabIndex = 6
        Me.Label1.Text = "List of shops:"
        '
        'grdShopItemInfo
        '
        Me.grdShopItemInfo.Cols = 3
        Me.grdShopItemInfo.FixedCols = 1
        Me.grdShopItemInfo.FixedRows = 1
        Me.grdShopItemInfo.Location = New System.Drawing.Point(12, 300)
        Me.grdShopItemInfo.Name = "grdShopItemInfo"
        Me.grdShopItemInfo.Rows = 10
        Me.grdShopItemInfo.Scrollbars = System.Windows.Forms.ScrollBars.Both
        Me.grdShopItemInfo.Size = New System.Drawing.Size(321, 157)
        Me.grdShopItemInfo.TabIndex = 7
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.Label2.Location = New System.Drawing.Point(12, 280)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(149, 17)
        Me.Label2.TabIndex = 8
        Me.Label2.Text = "Shop Item Information:"
        '
        'txtView
        '
        Me.txtView.Location = New System.Drawing.Point(277, 250)
        Me.txtView.Name = "txtView"
        Me.txtView.Size = New System.Drawing.Size(100, 20)
        Me.txtView.TabIndex = 9
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(12, 253)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(259, 13)
        Me.Label3.TabIndex = 10
        Me.Label3.Text = "Please enter the Shop Number you would like to view"
        '
        'txtAvgPrice
        '
        Me.txtAvgPrice.Location = New System.Drawing.Point(277, 224)
        Me.txtAvgPrice.Name = "txtAvgPrice"
        Me.txtAvgPrice.Size = New System.Drawing.Size(100, 20)
        Me.txtAvgPrice.TabIndex = 11
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(98, 227)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(173, 13)
        Me.Label4.TabIndex = 12
        Me.Label4.Text = "Total Average Price of items in Mall"
        '
        'frmMall
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(750, 469)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.txtAvgPrice)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.txtView)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.grdShopItemInfo)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnView)
        Me.Controls.Add(Me.btnCalcAvg)
        Me.Controls.Add(Me.btnCapItems)
        Me.Controls.Add(Me.btnCapShop)
        Me.Controls.Add(Me.btnInitial)
        Me.Controls.Add(Me.grdList)
        Me.Name = "frmMall"
        Me.Text = "Mall"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents grdList As UJGrid.UJGrid
    Friend WithEvents btnInitial As Button
    Friend WithEvents btnCapShop As Button
    Friend WithEvents btnCapItems As Button
    Friend WithEvents btnCalcAvg As Button
    Friend WithEvents btnView As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents grdShopItemInfo As UJGrid.UJGrid
    Friend WithEvents Label2 As Label
    Friend WithEvents txtView As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents txtAvgPrice As TextBox
    Friend WithEvents Label4 As Label
End Class
