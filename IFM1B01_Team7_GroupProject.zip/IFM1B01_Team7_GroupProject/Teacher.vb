﻿'*****************************************************************
' Team Number: 7
' Team Member 1 Details: Mayet, AA (222001975)
' Team Member 2 Details: Ross, CR (222016699)
' Team Member 3 Details: Mabatha, TC (222107004)
' Team Member 4 Details: Ashimwe, HE (222127212)
' Practical: Team 7 Project
' Class name: Teacher
'*****************************************************************

Option Strict On
Option Explicit On
Option Infer Off

Public Class Teacher

    'inheritents
    Inherits Person
    'variabes
    Private _Salary As Double
    Private _YearsTaught As Integer

    'constructor
    Public Sub New(Name As String, IDNumber As String, Age As Integer, years As Integer)

        MyBase.New(Name, IDNumber, Age)
        _YearsTaught = years

    End Sub

    'Properties
    Public ReadOnly Property Salary As Double
        Get
            CalcCostOfPerson()
            Return _Salary
        End Get
    End Property

    Public Property TYears As Integer
        Get
            Return _YearsTaught
        End Get
        Set(value As Integer)
            _YearsTaught = value
        End Set
    End Property

    'Methods
    Public Overrides Sub CalcCostOfPerson()
        _Salary = (_YearsTaught + 1) / 5 * 75000
        _Salary = (_Salary + 75000) * 12
    End Sub

End Class
