﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmUtopianSocialGrantsDepartment
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.btnAddStudent = New System.Windows.Forms.Button()
        Me.btnAverage = New System.Windows.Forms.Button()
        Me.txtDisplay = New System.Windows.Forms.TextBox()
        Me.btnSaveToFile = New System.Windows.Forms.Button()
        Me.btnHighestAvg = New System.Windows.Forms.Button()
        Me.txtHighest = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'btnAddStudent
        '
        Me.btnAddStudent.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAddStudent.Location = New System.Drawing.Point(12, 12)
        Me.btnAddStudent.Name = "btnAddStudent"
        Me.btnAddStudent.Size = New System.Drawing.Size(161, 64)
        Me.btnAddStudent.TabIndex = 0
        Me.btnAddStudent.Text = "Add Student"
        Me.btnAddStudent.UseVisualStyleBackColor = True
        '
        'btnAverage
        '
        Me.btnAverage.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAverage.Location = New System.Drawing.Point(12, 82)
        Me.btnAverage.Name = "btnAverage"
        Me.btnAverage.Size = New System.Drawing.Size(161, 64)
        Me.btnAverage.TabIndex = 2
        Me.btnAverage.Text = "Average"
        Me.btnAverage.UseVisualStyleBackColor = True
        '
        'txtDisplay
        '
        Me.txtDisplay.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDisplay.Location = New System.Drawing.Point(179, 12)
        Me.txtDisplay.Multiline = True
        Me.txtDisplay.Name = "txtDisplay"
        Me.txtDisplay.ReadOnly = True
        Me.txtDisplay.Size = New System.Drawing.Size(195, 204)
        Me.txtDisplay.TabIndex = 3
        '
        'btnSaveToFile
        '
        Me.btnSaveToFile.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSaveToFile.Location = New System.Drawing.Point(12, 152)
        Me.btnSaveToFile.Name = "btnSaveToFile"
        Me.btnSaveToFile.Size = New System.Drawing.Size(161, 64)
        Me.btnSaveToFile.TabIndex = 4
        Me.btnSaveToFile.Text = "Save to File"
        Me.btnSaveToFile.UseVisualStyleBackColor = True
        '
        'btnHighestAvg
        '
        Me.btnHighestAvg.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnHighestAvg.Location = New System.Drawing.Point(12, 222)
        Me.btnHighestAvg.Name = "btnHighestAvg"
        Me.btnHighestAvg.Size = New System.Drawing.Size(161, 64)
        Me.btnHighestAvg.TabIndex = 5
        Me.btnHighestAvg.Text = "Highest Average Student"
        Me.btnHighestAvg.UseVisualStyleBackColor = True
        '
        'txtHighest
        '
        Me.txtHighest.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtHighest.Location = New System.Drawing.Point(179, 241)
        Me.txtHighest.Name = "txtHighest"
        Me.txtHighest.ReadOnly = True
        Me.txtHighest.Size = New System.Drawing.Size(195, 22)
        Me.txtHighest.TabIndex = 6
        '
        'frmUtopianSocialGrantsDepartment
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(387, 296)
        Me.Controls.Add(Me.txtHighest)
        Me.Controls.Add(Me.btnHighestAvg)
        Me.Controls.Add(Me.btnSaveToFile)
        Me.Controls.Add(Me.txtDisplay)
        Me.Controls.Add(Me.btnAverage)
        Me.Controls.Add(Me.btnAddStudent)
        Me.Name = "frmUtopianSocialGrantsDepartment"
        Me.Text = "Utopian Social Grants Department"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnAddStudent As Button
    Friend WithEvents btnAverage As Button
    Friend WithEvents txtDisplay As TextBox
    Friend WithEvents btnSaveToFile As Button
    Friend WithEvents btnHighestAvg As Button
    Friend WithEvents txtHighest As TextBox
End Class
