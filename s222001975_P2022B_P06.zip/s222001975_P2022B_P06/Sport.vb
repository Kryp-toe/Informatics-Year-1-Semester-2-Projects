﻿'*********************************************************************************************
' Surname, Initials: Mayet, AA
' Student Number: 222001975
' Practical: P06
'*********************************************************************************************

Option Explicit On
Option Strict On
Option Infer Off

'Abstract(parent) class
Public MustInherit Class Sport

    Private _nTeams As Integer
    'Declare compositon class
    Private _Teams() As Team

    'Class constructor
    Public Sub New(NT As Integer)

        _nTeams = NT
        ReDim _Teams(_nTeams)

    End Sub

    'Property methods
    Public Property nteams As Integer
        Get
            Return _nTeams
        End Get
        Set(value As Integer)
            _nTeams = value
        End Set
    End Property

    Public Property Teams(index As Integer) As Team
        Get
            Return _Teams(index)
        End Get
        Set(value As Team)
            _Teams(index) = value
        End Set
    End Property

    'Overidable function for calculating the score
    Public Overridable Function CalcScore(x As Integer, y As Integer, z As Integer, a As Integer) As String
        Return "0"
    End Function

End Class
